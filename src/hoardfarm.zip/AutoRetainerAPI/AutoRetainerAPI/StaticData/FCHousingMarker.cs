﻿namespace AutoRetainerAPI.StaticData;
/// <summary>
/// This enum contains markers of free company property owned by it
/// </summary>
public enum FCHousingMarker
{
    SmallYellow = 60761,
    MediumYellow = 60762,
    LargeYellow = 60763,
    SmallBlue = 60764,
    MediumBlue = 60765,
    LargeBlue = 60766,
}
