﻿using System;
using System.Collections.Generic;
using Dalamud.Configuration;

namespace HoardFarm.Model;

[Serializable]
public class Configuration : IPluginConfiguration
{
    public int Version { get; set; } = 1;
    
    public int HoardModeSave;
    public int HoardFarmMode;
    public int StopAfter = 50;
    public int StopAfterMode = 1;
    public int OverallRuns;
    public int OverallFoundHoards;
    public int OverallTime;
    public bool ShowOverlay = true;
    public bool ParanoidMode;
    public int MinWaitTime = 3;
    public int MaxWaitTime = 6;

    public bool RandomEnterDelay;
    public int RandomEnterDelayMin = 1;
    public int RandomEnterDelayMax = 10;

    public int TaskTimeoutSeconds = 10;  // only applies to Func<bool?> tasks (dungeon confirm), BaseTask uses own Timeout
    
    public bool DoRetainers;
    public int RetainerMode = 1;
    
    public string Language { get; set; } = "zh";

    public string? UniqueId { get; set; }

    public bool DisableStatisticCollection = true;

    public bool DebugLogging = false;

    public string PomanderCommand { get; set; } = "";
    public string HoardArrivedCommand { get; set; } = "";

    public bool PauseWhenPlayersNearby = true;
    public bool SkipDefensivePomanders;
    public int IntuitionThrottleMs = 500;
    public bool WarnTimeoutEnabled = true;
    public int WarnTimeoutMinutes = 5;
    public List<string> PlayerWhitelist { get; set; } = [];

    public void Save()
    {
        PluginInterface.SavePluginConfig(this);
    }
}
