﻿using System;
using HoardFarm.Tasks;
using HoardFarm.Tasks.Base;

namespace HoardFarm.Utils;

public static class TaskManagerUtil
{
    
    public static void Enqueue(IBaseTaskGroup taskGroup)
    {
        foreach (var o in taskGroup.GetTaskList())
        {
            switch (o)
            {
                case BaseTask task:
                    Enqueue(task);
                    continue;
                case Func<bool?> func:
                    Enqueue(func);
                    continue;
                default:
                    throw new Exception("Invalid task type");
            }
        }

        
    }
    
    public static void Enqueue(BaseTask task, int timeLimitMs = -1, string? name = null)
    {
        TaskManager.Enqueue(task.Run, timeLimitMs >= 0 ? timeLimitMs : task.Timeout, name);
    }
    
    public static void Enqueue(BaseTask task) => Enqueue(task, task.Timeout);
    public static void Enqueue(BaseTask task, string? name = null) => Enqueue(task, task.Timeout, name);
    
    public static void Enqueue(Func<bool?> task, int timeLimitMs = -1, string? name = null)
    {
        TaskManager.Enqueue(task, timeLimitMs >= 0 ? timeLimitMs : Config.TaskTimeoutSeconds * 1000, name);
    }

    public static void EnqueueImmediate(BaseTask task, int timeLimitMs = -1, string? name = null)
    {
        TaskManager.EnqueueImmediate(task.Run, timeLimitMs >= 0 ? timeLimitMs : task.Timeout, name);
    }
    
    public static void Enqueue(Func<bool?> task) => Enqueue(task, Config.TaskTimeoutSeconds * 1000);
    public static void Enqueue(Func<bool?> task, string? name = null) => Enqueue(task, Config.TaskTimeoutSeconds * 1000, name);

    public static void EnqueueWait(int delayMS)
    {
        TaskManager.DelayNext(delayMS);
    }
    
    public static void EnqueueImmediate(BaseTask task, string? name = null) => EnqueueImmediate(task, Config.TaskTimeoutSeconds * 1000, name);
    public static void EnqueueImmediate(BaseTask task) => EnqueueImmediate(task, Config.TaskTimeoutSeconds * 1000);
    
    public static void EnqueueImmediate(Func<bool?> task, int timeLimitMs = 10000, string? name = null)
    {
        TaskManager.EnqueueImmediate(task, timeLimitMs, name);
    }
    
    public static void EnqueueImmediate(Func<bool?> task, string? name = null) => EnqueueImmediate(task, 10000, name);
    public static void EnqueueImmediate(Func<bool?> task) => EnqueueImmediate(task, 10000);
    
    public static void EnqueueWaitImmediate(int delayMS)
    {
        TaskManager.DelayNextImmediate(delayMS);
    }

    public static int GetConfirmTimeout()
    {
        return Config.RandomEnterDelay
            ? Random.Shared.Next(Config.RandomEnterDelayMin, Config.RandomEnterDelayMax + 1)
            : Config.TaskTimeoutSeconds;
    }
}
