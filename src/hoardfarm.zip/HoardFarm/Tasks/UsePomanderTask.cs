﻿using System;
using Dalamud.Game.ClientState.Conditions;
using ECommons.Automation;
using ECommons.DalamudServices;
using ECommons.Throttlers;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;
using FFXIVClientStructs.FFXIV.Component.GUI;
using HoardFarm.Model;
using HoardFarm.Tasks.Base;

namespace HoardFarm.Tasks;

public class UsePomanderTask(Pomander pomander, bool wait = true, Action? onUsed = null) : BaseTask
{
    private bool used;

    public override unsafe bool? Run()
    {
        if (Svc.Condition[ConditionFlag.BetweenAreas] || Svc.Condition[ConditionFlag.BetweenAreas51]
            || Svc.Condition[ConditionFlag.WaitingForDuty] || Svc.Condition[ConditionFlag.WaitingForDutyFinder]
            || Svc.Condition[ConditionFlag.OccupiedInQuestEvent])
            return false;

        if (TryGetAddonByName<AtkUnitBase>("DeepDungeonStatus", out var addon) && IsAddonReady(addon))
        {
            if (CanUsePomander(pomander))
            {
                Callback.Fire(addon, true, 11, (int)pomander);
                if (!used)
                {
                    used = true;
                    onUsed?.Invoke();
                }
                if(wait)
                    EnqueueWaitImmediate(2000);
            }
            return true;
        }

        if (EzThrottler.Throttle("OpenDeepDungeonStatus", 2000)) {
            AgentDeepDungeonStatus.Instance()->AgentInterface.Show();
        }

        return false;
    }
}
