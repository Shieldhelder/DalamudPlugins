﻿using System.Diagnostics;
using Dalamud.Interface;
using Dalamud.Interface.Windowing;
using Dalamud.Bindings.ImGui;
using HoardFarm.Data;

namespace HoardFarm.Windows;

public class ConfigWindow() : Window(Strings.ConfigWindow_Title, ImGuiWindowFlags.AlwaysAutoResize)
{
    private string whitelistInput = "";
    public override void Draw()
    {
        ImGui.Text(Strings.ConfigWindow_GreetingText);
        ImGui.Text(Strings.ConfigWindow_SupportMe);
        ImGui.PushStyleColor(ImGuiCol.Button, 0xFF000000 | 0x005E5BFF);
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, 0xDD000000 | 0x005E5BFF);
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0xAA000000 | 0x005E5BFF);

        if (ImGui.Button(Strings.ConfigWindow_SupportKofi))
            Process.Start(new ProcessStartInfo
            {
                FileName = "https://ko-fi.com/jukkales",
                UseShellExecute = true
            });

        ImGui.PopStyleColor(3);
        ImGui.Spacing();
        ImGui.Separator();

        if (ImGui.Button(Strings.ConfigWindow_ResetStatistics))
        {
            Config.OverallRuns = 0;
            Config.OverallFoundHoards = 0;
            Config.OverallTime = 0;
            Config.Save();
        }

        if (ImGui.Checkbox(Strings.ConfigWindow_OpenHoardfarmOverlay, ref Config.ShowOverlay))
            Config.Save();

        if (ImGui.Checkbox("信息调试日志", ref Config.DebugLogging))
            Config.Save();

        if (ImGui.Checkbox("红玉海有玩家时暂停", ref Config.PauseWhenPlayersNearby))
            Config.Save();

        if (Config.PauseWhenPlayersNearby)
        {
            ImGui.Indent();

            if (ImGui.Checkbox("超时报警", ref Config.WarnTimeoutEnabled))
                Config.Save();

            if (Config.WarnTimeoutEnabled)
            {
                ImGui.SetNextItemWidth(80);
                if (ImGui.SliderInt("超时时间（分钟）", ref Config.WarnTimeoutMinutes, 1, 30))
                    Config.Save();
            }

            ImGui.Text("白名单 (Name@Server)");
            ImGui.SetNextItemWidth(200);
            var input = whitelistInput;
            if (ImGui.InputText("##whitelistInput", ref input, 128))
                whitelistInput = input;
            ImGui.SameLine();
            if (ImGui.Button("添加") && !string.IsNullOrWhiteSpace(whitelistInput))
            {
                Config.PlayerWhitelist.Add(whitelistInput.Trim());
                Config.Save();
                whitelistInput = "";
            }
            for (var i = 0; i < Config.PlayerWhitelist.Count; i++)
            {
                ImGui.PushID($"wl_{i}");
                ImGui.Text(Config.PlayerWhitelist[i]);
                ImGui.SameLine();
                if (ImGui.Button("移除"))
                {
                    Config.PlayerWhitelist.RemoveAt(i);
                    Config.Save();
                }
                ImGui.PopID();
            }
            ImGui.Unindent();
        }

        if (ImGui.Checkbox("随机进本延迟", ref Config.RandomEnterDelay))
            Config.Save();

        if (ImGui.Checkbox("不使用隐身及魔石(无视风险继续运行)", ref Config.SkipDefensivePomanders))
            Config.Save();

        ImGui.SetNextItemWidth(200);
        if (ImGui.SliderInt("调整感知宝藏节流时间", ref Config.IntuitionThrottleMs, 0, 2000))
            Config.Save();

        if (Config.RandomEnterDelay)
        {
            ImGui.Indent();
            ImGui.SetNextItemWidth(80);
            if (ImGui.SliderInt("最短（秒）", ref Config.RandomEnterDelayMin, 1, 30))
            {
                if (Config.RandomEnterDelayMin > Config.RandomEnterDelayMax)
                    Config.RandomEnterDelayMin = Config.RandomEnterDelayMax;
                Config.Save();
            }
            ImGui.SameLine();
            ImGui.SetNextItemWidth(80);
            if (ImGui.SliderInt("最长（秒）", ref Config.RandomEnterDelayMax, 1, 30))
            {
                if (Config.RandomEnterDelayMax < Config.RandomEnterDelayMin)
                    Config.RandomEnterDelayMax = Config.RandomEnterDelayMin;
                Config.Save();
            }
            ImGui.Unindent();
        }
        else
        {
            ImGui.SetNextItemWidth(120);
            if (ImGui.SliderInt("进本确认等待时间", ref Config.TaskTimeoutSeconds, 1, 30))
                Config.Save();
        }

        ImGui.Spacing();
        ImGui.Separator();
        ImGui.Text("查找到宝藏后执行");
        ImGui.SetNextItemWidth(-1);
        var hoardFoundCmd = Config.PomanderCommand ?? "";
        if (ImGui.InputText("##hoardFoundCmd", ref hoardFoundCmd, 256))
        {
            Config.PomanderCommand = hoardFoundCmd;
            Config.Save();
        }

        ImGui.Text("到达宝藏后执行");
        ImGui.SetNextItemWidth(-1);
        var hoardArrivedCmd = Config.HoardArrivedCommand ?? "";
        if (ImGui.InputText("##hoardArrivedCmd", ref hoardArrivedCmd, 256))
        {
            Config.HoardArrivedCommand = hoardArrivedCmd;
            Config.Save();
        }

        ImGui.Spacing();
        ImGui.Separator();

        if (ImGui.Checkbox(Strings.ConfigWindow_SlowMode, ref Config.ParanoidMode))
            Config.Save();
        ImGui.SameLine();
        ImGui.PushFont(UiBuilder.IconFont);
        ImGui.Text(FontAwesomeIcon.QuestionCircle.ToIconString());
        ImGui.PopFont();
        if (ImGui.IsItemHovered())
            ImGui.SetTooltip(Strings.ConfigWindow_SlowMode_Help);

        if (Config.ParanoidMode)
        {
            ImGui.Indent();
            ImGui.Text(Strings.ConfigWindow_WaitBetween);
            ImGui.SetNextItemWidth(80);
            if (ImGui.SliderInt("###MinWait", ref Config.MinWaitTime, 0, 10, Strings.ConfigWindow_Seconds))
            {
                if (Config.MinWaitTime > Config.MaxWaitTime) Config.MinWaitTime = Config.MaxWaitTime;
                Config.Save();
            }
            ImGui.SameLine();
            ImGui.Text(Strings.ConfigWindow_And);
            ImGui.SameLine();
            ImGui.SetNextItemWidth(80);
            if (ImGui.SliderInt("###MaxWait", ref Config.MaxWaitTime, 0, 20, Strings.ConfigWindow_Seconds))
            {
                if (Config.MaxWaitTime < Config.MinWaitTime) Config.MaxWaitTime = Config.MinWaitTime;
                Config.Save();
            }
            ImGui.Unindent();
        }
    }
}
