﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using Dalamud.Game.Chat;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.Text;
using Dalamud.Game.Text.SeStringHandling;
using Dalamud.Plugin.Services;
using Dalamud.Utility;
using ECommons.DalamudServices;
using ECommons.GameHelpers;
using ECommons.Throttlers;
using HoardFarm.Data;
using HoardFarm.IPC;
using HoardFarm.Model;
using HoardFarm.Tasks;
using HoardFarm.Tasks.TaskGroups;
using Lumina.Excel.Sheets;
using Newtonsoft.Json;

namespace HoardFarm.Service;

public class HoardFarmService : IDisposable
{
    private readonly string hoardFoundMessage;
    private readonly string noHoardMessage;
    private readonly Dictionary<uint, MapObject> objectPositions = new();
    private readonly string senseHoardMessage;
    private readonly List<uint> visitedObjectIds = [];
    public bool FinishRun;
    private bool hoardAvailable;

    private bool hoardFound;
    private bool hoardModeActive;
    public string HoardModeError = "";

    public string HoardModeStatus = "";
    private bool warned5Min;
    private Vector3 hoardPosition = Vector3.Zero;
    private bool intuitionUsed;
    private DateTime? intuitionFailedAt;
    private DateTime intuitionLastCheck;
    private bool? lastHoardCollected;
    private bool? lastHoardFound;
    private DateTime lastTick = DateTime.Now;
    private DateTime? movementEnd;
    private DateTime? movementStart;
    private bool movingToHoard;

    private bool running;
    private DateTime runStarted;
    private bool safetyUsed;
    private bool searchMode;
    public int SessionFoundHoards;
    public int SessionRuns;
    public int SessionTime;
    public DateTime? WaitingSince;

    private ushort? currentTerritoryType;

    private DateTime? timingStart;

    public HoardFarmService()
    {
        try
        {
            var senseMsg = DataManager.GetExcelSheet<LogMessage>()?.GetRow(7272);
            var noMsg = DataManager.GetExcelSheet<LogMessage>()?.GetRow(7273);
            var foundMsg = DataManager.GetExcelSheet<LogMessage>()?.GetRow(7274);
            hoardFoundMessage = foundMsg?.Text.ToDalamudString().GetText() ?? "";
            senseHoardMessage = senseMsg?.Text.ToDalamudString().GetText() ?? "";
            noHoardMessage = noMsg?.Text.ToDalamudString().GetText() ?? "";
        }
        catch (Exception ex)
        {
            PluginLog.Error(ex, "[HoardFarm] LogMessage 加载失败");
            hoardFoundMessage = "";
            senseHoardMessage = "";
            noHoardMessage = "";
        }

        if (string.IsNullOrWhiteSpace(senseHoardMessage))
            senseHoardMessage = "这一层似乎有宝藏……";
        if (string.IsNullOrWhiteSpace(noHoardMessage))
            noHoardMessage = "这一层似乎没有宝藏……";
        if (string.IsNullOrWhiteSpace(hoardFoundMessage))
            hoardFoundMessage = "可以发现宝藏了！";

        PluginLog.Information($"[HoardFarm] 消息模板: sense=[{senseHoardMessage}] no=[{noHoardMessage}] found=[{hoardFoundMessage}]");

        ClientState.TerritoryChanged += OnMapChange;
        Framework.Update += OnTick;
        ChatGui.ChatMessage += OnChatMessage;
    }

    public bool HoardMode
    {
        get => hoardModeActive;
        set
        {
            hoardModeActive = value;
            if (hoardModeActive)
                EnableFarm();
            else
                DisableFarm();
        }
    }

    public void Dispose()
    {
        ChatGui.ChatMessage -= OnChatMessage;
        ClientState.TerritoryChanged -= OnMapChange;
        Framework.Update -= OnTick;
    }

    private void DisableFarm()
    {
        running = false;
        TaskManager.Abort();
        HoardModeStatus = "";
        Reset();

        if (RetainerScv.Running) RetainerScv.FinishProcess();
        EnableIfNeeded(true);
    }

    private void EnableFarm()
    {
        Reset();
        SessionTime = 0;
        SessionRuns = 0;
        SessionFoundHoards = 0;
        running = true;
        HoardModeStatus = Strings.HoardFarm_Status_Running;
        HoardModeError = "";
    }

    private void Reset()
    {
        Config.Save();
        intuitionUsed = false;
        hoardFound = false;
        hoardPosition = Vector3.Zero;
        movingToHoard = false;
        hoardAvailable = false;
        searchMode = false;
        FinishRun = false;
        safetyUsed = false;
        objectPositions.Clear();
        runStarted = DateTime.Now;
        WaitingSince = null;
        warned5Min = false;
        intuitionFailedAt = null;
        intuitionLastCheck = default;
    }

    private bool SearchLogic()
    {
        HoardModeStatus = Strings.HoardFarm_Status_Searching;

        if (!TaskManager.IsBusy)
        {
            if (!objectPositions.Where(e => !visitedObjectIds.Contains(e.Value.ObjectId))
                                .Where(e => ChestIDs.Contains(e.Value.DataId))
                                .OrderBy(e => e.Value.Position.Distance(Player.Position))
                                .Select(e => e.Value)
                                .TryGetFirst(out var next))
            {
                if (!objectPositions.Where(e => !visitedObjectIds.Contains(e.Value.ObjectId))
                                    .OrderBy(e => e.Value.Position.Distance(Player.Position))
                                    .Select(e => e.Value)
                                    .TryGetFirst(out next))
                {
                    // We should never reach here normally .. but "never" is still a chance > 0% ;)
                    LeaveDuty(Strings.HoardFarm_Status_Unreachable);
                    return true;
                }
            }

            visitedObjectIds.Add(next!.ObjectId);
            Enqueue(new PathfindTask(next.Position, true), 60 * 1000,
                    string.Format(Strings.HoardFarm_Status_SearchingObject, next.ObjectId));
        }

        FindHoardPosition();
        if (hoardPosition != Vector3.Zero)
        {
            NavmeshIPC.PathStop();
            TaskManager.Abort();
            return true;
        }

        return false;
    }

    private void OnTick(IFramework framework)
    {
        if (!running || DateTime.Now - lastTick < TimeSpan.FromSeconds(1))
            return;

        lastTick = DateTime.Now;

        // Retainer do not increase runtime
        if (RetainerScv.Running)
        {
            HoardModeStatus = Strings.HoardFarm_Status_RetainerRunning;
            return;
        }

        SessionTime++;
        Config.OverallTime++;

        if (!NavmeshIPC.NavIsReady())
        {
            HoardModeStatus = Strings.HoardFarm_Status_WaitingNavmesh;
            return;
        }

        UpdateObjectPositions();
        SafetyChecks();

        if (searchMode && hoardPosition == Vector3.Zero)
        {
            if (!SearchLogic())
                return;
        }

        if (Player.Available && Player.Territory.Value.RowId == HoHMapId1)
        {
            HoardModeStatus = Strings.HoardFarm_Status_Error_Unprepared;
            return;
        }

        if (!TaskManager.IsBusy && hoardModeActive)
        {
            if (CheckDone() && !FinishRun)
            {
                FinishRun = true;
                GatherData();
                return;
            }

            if (!InHoH && !InRubySea && NotBusy() && !KyuseiInteractable())
            {
                HoardModeStatus = Strings.HoardFarm_Status_MoveToHoH;
                Enqueue(new MoveToHoHTask());
                EnqueueWait(1000);
            }

            if (InRubySea && NotBusy() && KyuseiInteractable())
            {
                if (FinishRun)
                {
                    HoardModeStatus = Strings.HoardFarm_Status_Finished;
                    HoardMode = false;
                    return;
                }

                if (Config.PauseWhenPlayersNearby && NearbyPlayerCount() > 0)
                {
                    HoardModeStatus = "附近有玩家，暂停等待";
                    WaitingSince ??= DateTime.Now;
                    if (Config.WarnTimeoutEnabled && !warned5Min
                        && DateTime.Now.Subtract(WaitingSince.Value).TotalMinutes >= Config.WarnTimeoutMinutes)
                    {
                        warned5Min = true;
                        ChatGui.Print($"[HoardFarm] 当前已等待{Config.WarnTimeoutMinutes}分钟，警惕小警察");
                    }
                    return;
                }
                WaitingSince = null;
                warned5Min = false;

                if (CheckRetainer())
                {
                    // Do retainers first
                    return;
                }

                GatherData();
                timingStart = DateTime.Now;
                HoardModeStatus = Strings.HoardFarm_Status_EnteringHoH;
                if (Config.ParanoidMode)
                    EnqueueWait(Random.Shared.Next(Config.MinWaitTime * 1000, Config.MaxWaitTime * 1000));
                Enqueue(new EnterHeavenOnHigh());
            }

            if (InHoH && NotBusy())
            {
                if (!intuitionUsed)
                {
                    if (!CanUsePomander(Pomander.Intuition))
                    {
                        intuitionFailedAt ??= DateTime.Now;
                        if (DateTime.Now.Subtract(intuitionFailedAt.Value).TotalSeconds < 2)
                            return;
                        intuitionFailedAt = DateTime.Now;
                        intuitionLastCheck = default;
                        return;
                    }
                    intuitionFailedAt = null;

                    if (intuitionLastCheck == default)
                    {
                        intuitionLastCheck = DateTime.Now;
                        return;
                    }
                    if ((DateTime.Now - intuitionLastCheck).TotalMilliseconds < Config.IntuitionThrottleMs)
                        return;
                    intuitionLastCheck = default;

                    if (!CheckMinimalSetup())
                    {
                        Error(
                            Strings.HoardFarm_Status_Error_MinimalSetup);
                        return;
                    }

                    if (CanUsePomander(Pomander.Intuition))
                    {
                        Enqueue(new UsePomanderTask(Pomander.Intuition, onUsed: () => intuitionUsed = true), "Use Intuition");
                    }
                }
                else
                {
                    if (hoardAvailable)
                    {
                        lastHoardFound = true;
                        FindHoardPosition();

                        if (hoardPosition != Vector3.Zero)
                        {
                            if (!movingToHoard)
                            {
                                // if (!Concealment)
                                // {
                                //     Enqueue(new UsePomanderTask(Pomander.Concealment, false), "Use Concealment");
                                // }
                                movementStart ??= DateTime.Now;
                                Enqueue(new PathfindTask(hoardPosition, true, 1.5f, onComplete: () =>
                                {
                                    ExecuteStoredCommand(Config.HoardArrivedCommand);
                                }), 60 * 1000, "Move to Hoard");
                                movingToHoard = true;
                                HoardModeStatus = Strings.HoardFarm_Status_MoveToHoard;
                            }
                        }
                        else
                        {
                            if (Config.HoardFarmMode == 1)
                            {
                                LeaveDuty(Strings.HoardFarm_Status_Leaving);
                                return;
                            }

                            if (!hoardFound)
                            {
                                movementStart = DateTime.Now;
                                if (!Config.SkipDefensivePomanders)
                                    Enqueue(new UsePomanderTask(Pomander.Concealment), "Use Concealment");
                                searchMode = true;
                                return;
                            }
                        }

                        if (hoardFound)
                        {
                            LeaveDuty(Strings.HoardFarm_Status_Leaving);
                        }
                    }
                    else
                        LeaveDuty(Strings.HoardFarm_Status_Leaving);
                }
            }
        }
    }

    private void SafetyChecks()
    {
        if (InHoH && intuitionUsed)
        {
            if (DateTime.Now.Subtract(runStarted).TotalSeconds > 130 && !Svc.Condition[ConditionFlag.InCombat])
            {
                TaskManager.Abort();
                NavmeshIPC.PathStop();
                LeaveDuty(Strings.HoardFarm_Status_Timeout);
                return;
            }

            if (!Config.SkipDefensivePomanders)
            {
                if (IsMoving())
                {
                    if (!Concealment)
                    {
                        if (CanUsePomander(Pomander.Concealment))
                        {
                            if (EzThrottler.Check("Concealment"))
                            {
                                EzThrottler.Throttle("Concealment", 2000);
                                new UsePomanderTask(Pomander.Concealment, false).Run();
                                return;
                            }
                        }
                        else if (CanUsePomander(Pomander.Safety) && !safetyUsed && EzThrottler.Check("Concealment"))
                        {
                            if (EzThrottler.Check("Safety"))
                            {
                                EzThrottler.Throttle("Safety", 2000);
                                new UsePomanderTask(Pomander.Safety, false).Run();
                                safetyUsed = true;
                                return;
                            }
                        }
                    }
                }

                if (Svc.Condition[ConditionFlag.InCombat])
                {
                    if (CanUseMagicite() && EzThrottler.Check("Magicite"))
                    {
                        EzThrottler.Throttle("Magicite", 6000);
                        new UseMagiciteTask().Run();
                    }
                }
            }

            if (Svc.Condition[ConditionFlag.Unconscious]) LeaveDuty(Strings.HoardFarm_Status_PlayerDied);
        }
    }

    private void UpdateObjectPositions()
    {
        foreach (var gameObject in ObjectTable)
            objectPositions.TryAdd(gameObject.EntityId,
                                   new MapObject(gameObject.EntityId, gameObject.BaseId, gameObject.Position));
    }

    private bool CheckRetainer()
    {
        if (Config.DoRetainers
            && RetainerService.CheckRetainersDone(Config.RetainerMode == 1)
            && RetainerScv.CanRunRetainer())
        {
            RetainerScv.StartProcess();
            return true;
        }

        return false;
    }

    private bool CheckMinimalSetup()
    {
        if (!CanUsePomander(Pomander.Intuition)) return false;
        if (Config.SkipDefensivePomanders) return true;
        if (CanUsePomander(Pomander.Concealment)) return true;

        return CanUsePomander(Pomander.Safety) && CanUseMagicite();
    }

    private void LeaveDuty(string message)
    {
        HoardModeStatus = message;
        SessionRuns++;
        Config.OverallRuns++;
        Enqueue(new LeaveDutyTask());
    }

    private void Error(string message)
    {
        HoardModeStatus = Strings.HoardFarm_Status_Error;
        HoardModeError = message;
        FinishRun = true;
        Enqueue(new LeaveDutyTask());
    }

    private void FindHoardPosition()
    {
        if (hoardPosition == Vector3.Zero &&
            ObjectTable.TryGetFirst(gameObject => gameObject.BaseId == AccursedHoardId, out var hoard))
            hoardPosition = hoard.Position;
    }

    private bool CheckDone()
    {
        switch (Config.StopAfterMode)
        {
            case 0 when SessionRuns >= Config.StopAfter:
            case 1 when SessionFoundHoards >= Config.StopAfter:
            case 2 when SessionTime >= Config.StopAfter * 60:
                return true;
            default:
                return false;
        }
    }

    private void OnMapChange(uint territoryType)
    {
        if (Config.DebugLogging)
            PluginLog.Information($"[HoardFarm] OnMapChange: {territoryType}");
        if (!running) return;

        if (territoryType is HoHMapId11 or HoHMapId21)
        {
            Reset();
            HoardModeStatus = Strings.HoardFarm_Status_Waiting;
            currentTerritoryType = (ushort)territoryType;
        }
    }

    private void OnChatMessage(Dalamud.Game.Chat.IHandleableChatMessage msg)
    {
        var text = msg.Message.TextValue;
        if (Config.DebugLogging)
            PluginLog.Information($"ChatMessage: [{msg.LogKind}] {text}");
        if (!running || string.IsNullOrWhiteSpace(text)) return;
        text = text.Trim();

        var isSystemMsg = msg.LogKind == XivChatType.SystemMessage;

        if (isSystemMsg && senseHoardMessage.Length > 0 && text.Contains(senseHoardMessage, StringComparison.Ordinal))
        {
            PluginLog.Information("检测到了宝藏提示");
            intuitionUsed = true;
            hoardAvailable = true;
            HoardModeStatus = Strings.HoardFarm_Status_HoardFound;
            Svc.Framework.RunOnTick(() => ExecuteStoredCommand(Config.PomanderCommand), TimeSpan.FromSeconds(1));
        }
        else if (isSystemMsg && text.Contains("这一层似乎有宝藏", StringComparison.Ordinal))
        {
            PluginLog.Information("检测到了宝藏提示 (hardcoded match)");
            intuitionUsed = true;
            hoardAvailable = true;
            HoardModeStatus = Strings.HoardFarm_Status_HoardFound;
            Svc.Framework.RunOnTick(() => ExecuteStoredCommand(Config.PomanderCommand), TimeSpan.FromSeconds(1));
        }

        if (isSystemMsg && noHoardMessage.Length > 0 && text.Contains(noHoardMessage, StringComparison.Ordinal))
        {
            PluginLog.Information("未发现宝藏");
            intuitionUsed = true;
            hoardAvailable = false;
            TaskManager.Abort();
            LeaveDuty(Strings.HoardFarm_Status_NoHoard);
        }

        if (isSystemMsg && hoardFoundMessage.Length > 0 && text.Contains(hoardFoundMessage, StringComparison.Ordinal))
        {
            PluginLog.Information("宝藏已收集");
            hoardFound = true;
            movementEnd = DateTime.Now;
            lastHoardCollected = true;
            SessionFoundHoards++;
            Config.OverallFoundHoards++;
            Achievements.Progress++;
            TaskManager.Abort();
            LeaveDuty(Strings.HoardFarm_Status_Done);
        }
    }

    private void GatherData()
    {
        if (timingStart == null || currentTerritoryType == null)
        {
            timingStart = null;
            lastHoardFound = false;
            lastHoardCollected = false;
            movementStart = null;
            movementEnd = null;
            return;
        }

        try
        {
            var data = new CollectedData
            {
                Sender = Config.UniqueId ?? "unknown",
                Runtime = (DateTime.Now - timingStart.Value).TotalMilliseconds,
                TerritoryTyp = currentTerritoryType.Value,
                SafetyMode = Config.HoardFarmMode == 1
            };

            if (lastHoardFound.HasValue) data.HoardFound = lastHoardFound.Value;
            if (lastHoardCollected.HasValue) data.HoardCollected = lastHoardCollected.Value;

            if (movementStart.HasValue && movementEnd.HasValue)
                data.MoveTime = (movementEnd.Value - movementStart.Value).TotalMilliseconds;

            if (data.IsValid())
            {
                PluginLog.Information("Sending log: " + JsonConvert.SerializeObject(data, Formatting.None));
            }
        }
        catch (Exception ex)
        {
            PluginLog.Error(ex, "[HoardFarm] GatherData 异常");
        }


        timingStart = null;
        lastHoardFound = false;
        lastHoardCollected = false;
        movementStart = null;
        movementEnd = null;
    }

    private static void ExecuteStoredCommand(string? cmd)
    {
        if (string.IsNullOrWhiteSpace(cmd)) return;
        try
        {
            var parts = cmd.Split('|', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            if (parts.Length == 0) return;

            var first = parts[0];
            if (!first.StartsWith('/')) first = "/" + first;
            ECommons.Automation.Chat.SendMessage(first);

            for (var i = 1; i < parts.Length; i++)
            {
                var p = parts[i];
                if (!p.StartsWith('/')) p = "/" + p;
                var delay = TimeSpan.FromMilliseconds(i * 200);
                Svc.Framework.RunOnTick(() => ECommons.Automation.Chat.SendMessage(p), delay);
            }
        }
        catch (Exception ex) { ex.Log(); }
    }

    private record MapObject(uint ObjectId, uint DataId, Vector3 Position);
}
