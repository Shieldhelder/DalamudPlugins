﻿using AutoRetainerAPI;
using Dalamud.Game.ClientState.Objects;
using Dalamud.IoC;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using ECommons.Automation.LegacyTaskManager;
using HoardFarm.Model;

namespace HoardFarm.Service;

public class PluginService
{
    public static HoardFarm P = null!;

    [PluginService]
    public static IDalamudPluginInterface PluginInterface { get; private set; } = null!;
    [PluginService]
    public static IChatGui ChatGui { get; private set; } = null!;
    [PluginService]
    public static IClientState ClientState { get; private set; } = null!;
    [PluginService]
    public static ICommandManager CommandManager { get; private set; } = null!;
    [PluginService]
    public static ICondition Condition { get; private set; } = null!;
    [PluginService]
    public static IDataManager DataManager { get; private set; } = null!;
    [PluginService]
    public static IFlyTextGui FlyTextGui { get; private set; } = null!;
    [PluginService]
    public static IFramework Framework { get; private set; } = null!;
    [PluginService]
    public static IGameGui GameGui { get; private set; } = null!;
    [PluginService]
    public static IObjectTable ObjectTable { get; private set; } = null!;
    [PluginService]
    public static IPartyList PartyList { get; private set; } = null!;
    [PluginService]
    public static ITargetManager TargetManager { get; private set; } = null!;
    [PluginService]
    public static INotificationManager NotificationManager { get; private set; } = null!;
    [PluginService]
    public static IPluginLog PluginLog { get; private set; } = null!;
    public static Configuration Config { get; set; } = null!;
    public static HoardFarmService HoardService { get; set; } = null!;
    public static TaskManager TaskManager { get; set; } = null!;
    public static AchievementService Achievements { get; set; } = null!;
    public static AutoRetainerApi RetainerApi { get; set; } = null!;
    public static RetainerService RetainerScv { get; set; } = null!;
}
