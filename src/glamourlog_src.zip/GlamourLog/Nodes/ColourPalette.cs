namespace GlamourLog.Nodes;

/// <summary>
/// Theme-aware palette. Each color is resolved against <see cref="Configuration.Theme"/> at read time,
/// so node builders get the current scheme whenever windows are rebuilt.
/// </summary>
internal static class ColourPalette {
    public static Vector4 TitleWhite => T(Vector4.One, NearBlack);
    public static Vector4 PrimaryWhite => T(Vector4.One, NearBlack);
    public static Vector4 SubtitleBrown => T(new Vector4(157f / 255f, 131f / 255f, 91f / 255f, 1f), new Vector4(51f / 255f, 45f / 255f, 38f / 255f, 1f));
    public static Vector4 CategoryGold => T(new Vector4(216f / 255f, 187f / 255f, 125f / 255f, 1f), new Vector4(34f / 255f, 28f / 255f, 16f / 255f, 1f));
    public static Vector4 MutedGrey => T(new Vector4(0.65f, 0.65f, 0.65f, 1f), new Vector4(70f / 255f, 70f / 255f, 70f / 255f, 1f));
    public static Vector4 HeadingGrey => T(new Vector4(160f / 255f, 160f / 255f, 160f / 255f, 1f), new Vector4(40f / 255f, 40f / 255f, 40f / 255f, 1f));
    public static Vector4 BodyGrey => T(new Vector4(204f / 255f, 204f / 255f, 204f / 255f, 1f), new Vector4(28f / 255f, 28f / 255f, 28f / 255f, 1f));
    public static Vector4 Cream => T(new Vector4(238f / 255f, 225f / 255f, 197f / 255f, 1f), new Vector4(40f / 255f, 36f / 255f, 30f / 255f, 1f));
    public static Vector4 SidebarEdgeGold => T(new Vector4(230f / 255f, 167f / 255f, 58f / 255f, 1f), new Vector4(74f / 255f, 56f / 255f, 16f / 255f, 1f));
    public static Vector4 JournalHeaderBlack => new(0f, 0f, 0f, 1f);
    public static Vector4 CounterOutline => T(new Vector4(240f / 255f, 142f / 255f, 55f / 255f, 1f), new Vector4(0f, 0f, 0f, 0f));

    /// <summary>Text shown on dark control chrome (dropdowns / buttons) - stays light in every theme.</summary>
    public static Vector4 ControlText => Vector4.One;

    /// <summary>Text outline: kept only on dark panels, dropped in the light (DarkText) scheme where it looks bold.</summary>
    public static Vector4 TextOutline => T(new Vector4(230f / 255f, 167f / 255f, 58f / 255f, 1f), new Vector4(0f, 0f, 0f, 0f));

    private static readonly Vector4 NearBlack = new(26f / 255f, 26f / 255f, 26f / 255f, 1f);

    private static Vector4 T(Vector4 @default, Vector4 dark)
        => Configuration.C.Theme == UiTheme.DarkText ? dark : @default;
}
