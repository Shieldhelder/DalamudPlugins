using System.ComponentModel;
using KamiToolKit.Enums;
using KamiToolKit.Nodes;

namespace GlamourLog.Nodes;

public sealed class SetListSortControlNode : ResNode {
    private const float ButtonSize = 28f;
    private const float ButtonGap = 2f;

    public const float LayoutWidth = ButtonSize + ButtonGap + ButtonSize; // H-space in header (dir + sort; dropdown extends left)

    public readonly EnumDropDownNode<GlamourSetSortMode> SortDropDown;
    public readonly CircleButtonNode SortDirectionButton;
    public readonly CircleButtonNode SortButton;

    public SetListSortControlNode(ListSortDirection sortDirection) {
        var measure = DropDownListOption.CreateAxis14MeasureNode();
        measure.AttachNode(this);
        var listOuterWidth = DropDownListOption.OuterWidthForListLabels(measure, DropDownListOption.EnumDescriptions<GlamourSetSortMode>());
        Size = new Vector2(LayoutWidth, ButtonSize);

        var sortBlockEndX = LayoutWidth + ButtonGap;

        SortDropDown = new EnumDropDownNode<GlamourSetSortMode> {
            Position = new Vector2(sortBlockEndX - listOuterWidth, 0f),
            Size = new Vector2(listOuterWidth, ButtonSize),
            GetLabelFunction = SortModeLabel,
            Options =
            [
                GlamourSetSortMode.Alphabetical,
                GlamourSetSortMode.ItemLevel,
                GlamourSetSortMode.Patch,
            ],
        };
        // same as export dropdown: circle toggles list; hide stock row chrome + hitbox
        SortDropDown.BackgroundNode.IsVisible = false;
        SortDropDown.LabelNode.IsVisible = false;
        SortDropDown.CollapseArrowNode.IsVisible = false;
        SortDropDown.CollisionNode.NodeFlags = 0;
        SortDropDown.AttachNode(this);

        SortDirectionButton = new CircleButtonNode {
            Position = new Vector2(0f, 0f),
            Size = new Vector2(ButtonSize, ButtonSize),
            Icon = sortDirection == ListSortDirection.Ascending ? CircleButtonIcon.UpArrow : CircleButtonIcon.ArrowDown,
            TextTooltip = sortDirection == ListSortDirection.Ascending ? Addon.GetRow(8043).Text : Addon.GetRow(8044).Text,
        };
        SortDirectionButton.AttachNode(this);

        SortButton = new CircleButtonNode {
            Position = new Vector2(ButtonSize + ButtonGap, 0f),
            Size = new Vector2(ButtonSize, ButtonSize),
            Icon = CircleButtonIcon.Sort,
            TextTooltip = Addon.GetRow(1389).Text, // Sort
            OnClick = () => SortDropDown.Toggle(),
        };
        SortButton.AttachNode(this);
    }

    private static Lumina.Text.ReadOnly.ReadOnlySeString SortModeLabel(GlamourSetSortMode mode) => mode switch {
        GlamourSetSortMode.Alphabetical => Loc.T("Alphabetical", "按名称"),
        GlamourSetSortMode.ItemLevel => Loc.T("Item level", "物品等级"),
        _ => Loc.T("Patch", "版本"),
    };
}
