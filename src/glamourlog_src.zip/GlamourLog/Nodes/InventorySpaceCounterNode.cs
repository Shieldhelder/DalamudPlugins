using FFXIVClientStructs.FFXIV.Component.GUI;
using KamiToolKit.Nodes;

namespace GlamourLog.Nodes;

public sealed class InventorySpaceCounterNode : TextNode {
    public InventorySpaceCounterNode() {
        FontType = FontType.MiedingerMed;
        FontSize = 14;
        LineSpacing = 14;
        AlignmentType = AlignmentType.Right;
        TextColor = ColourPalette.PrimaryWhite;
        TextOutlineColor = ColourPalette.CounterOutline;
        String = string.Empty;
        AddTextFlags(Theme.Edge, TextFlags.Glare);
    }
}
