using FFXIVClientStructs.FFXIV.Component.GUI;
using GlamourLog.Tweaks.Cabinet;
using GlamourLog.Tweaks.PrismBox;

namespace GlamourLog.Services;

internal sealed class CommandService : IPluginCommands {
    public int InitOrder => 20;

    public string[] Commands { get; } = ["/glamourlog", "/gl"];
    public string HelpMessage => Loc.T("Toggle the GlamourLog window", "打开 GlamourLog 窗口");

    public CommandNode<object> Root => field ??= Build();

    private static CommandNode<object> Build()
        => CommandNode<object>.Root("Glamour Log commands")
            .Default(WindowsService.Get().ToggleMainWindow)
            .Sub("stop", Loc.T("Cancel any running tasks", "取消正在运行的任务"), Svc.Automation.Stop)
            .Sub("store", Loc.T("Store all eligible items in your armoire/dresser", "把所有可存放物品存入收藏柜/投影台"), () => {
                if (AtkUnitBase.IsAddonReady("Cabinet"))
                    Svc.Automation.Start(new StoreAllArmoireTask());
                if (AtkUnitBase.IsAddonReady("MiragePrismPrismBoxCrystallize"))
                    Svc.Automation.Start(new StoreAllDresserTask());
            });
}
