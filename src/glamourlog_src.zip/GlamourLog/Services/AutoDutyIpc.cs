using System.Reflection;
using Dalamud.Plugin.Ipc;

namespace GlamourLog.Services;

internal sealed class AutoDutyIpc : IPluginService {
    public enum FarmMode {
        Default,
        Unsynced,
        DutySupport,
        Trust,
    }

    private static readonly string[] GlamourFarmEnable = [
        "EnablePreLoopActions",
        "AutoRepair",
        "EnableBetweenLoopActions",
        "GlamourChestEntrust",
        "ArmoireEntrust",
        "EnableTerminationActions",
        "StopWhenDutyGathered",
    ];

    private const string SectionStart = "EnablePreLoopActions";
    private const string SectionEnd = "TerminationKeepActive";

    internal void FarmOutfit(uint cfcId, FarmMode mode = FarmMode.Default) {
        // Subscribers are created per call and not retained, so the handles are released right after the
        // operation and each use re-resolves AutoDuty's current IPC channel (avoids stale-channel issues).
        var pushOverrides = Svc.Interface.GetIpcSubscriber<object, bool>("AutoDuty.PushConfigOverrides");
        var contentHasPath = Svc.Interface.GetIpcSubscriber<uint, bool>("AutoDuty.ContentHasPath");
        var run = Svc.Interface.GetIpcSubscriber<uint, int, bool, object>("AutoDuty.Run");

        if (cfcId == 0 || ContentFinderCondition.GetRowRef(cfcId) is not { IsValid: true, Value.TerritoryType.RowId: > 0 and var territory }) {
            Svc.Chat.EchoMessage("GlamourLog: invalid duty.");
            return;
        }

        if (OwnershipService.Get().IsContentComplete(cfcId)) {
            Svc.Chat.EchoMessage("All outfit pieces from this duty collected.");
            return;
        }

        // AutoDuty.Run is a void provider (Action slot) but the subscriber below is Func-typed,
        // AutoDuty.Run is a void provider (Action slot) but the subscriber is Func-typed,
        // so HasFunction on it would always be false. Availability is keyed on the Func-typed
        // ContentHasPath / PushConfigOverrides instead; Run is fired via InvokeAction.
        if (!contentHasPath.HasFunction || !pushOverrides.HasFunction) {
            Svc.Chat.EchoMessage("AutoDuty is not loaded. Enable AutoDuty first, then try again.");
            return;
        }

        if (!contentHasPath.InvokeFunc(territory)) {
            var dutyName = ContentFinderCondition.GetRowRef(cfcId).Value.Name.ToString();
            Svc.Log.Warning($"[{nameof(AutoDutyIpc)}] No AutoDuty path for '{dutyName}' (cfc {cfcId}, TerritoryType {territory}).");
            Svc.Chat.EchoMessage($"AutoDuty has no path for this duty ('{dutyName}', TerritoryType {territory}). "
                                 + "If AutoDuty shows a path for it, the territory id above probably doesn't match the one AutoDuty stored the path under.");
            return;
        }

        // Overrides are best-effort: some keys may not exist in this AutoDuty build. Never block starting the run.
        var overrides = GetConfigOverrides(mode);
        try {
            if (!pushOverrides.InvokeFunc(overrides))
                Svc.Log.Warning($"[{nameof(AutoDutyIpc)}] AutoDuty rejected the config overrides; continuing with current settings.");
        }
        catch (Exception ex) {
            Svc.Log.Warning(ex, $"[{nameof(AutoDutyIpc)}] Failed to push config overrides; continuing with current settings.");
        }

        try {
            run.InvokeAction(territory, 0, true);
        }
        catch (Exception ex) {
            Svc.Chat.EchoError("Failed to start AutoDuty.");
            Svc.Log.Error(ex, $"[{nameof(AutoDutyIpc)}] AutoDuty.Run failed");
        }
    }

    // get all possible configs and set them to default
    private static Dictionary<string, string> GetConfigOverrides(FarmMode mode = FarmMode.Default) {
        if (TryBuildOverridesFromReflection(out var overrides))
            overrides = new Dictionary<string, string>(overrides, StringComparer.OrdinalIgnoreCase);
        else
            overrides = GlamourFarmEnable.ToDictionary(k => k, _ => "true", StringComparer.OrdinalIgnoreCase);

        switch (mode) {
            case FarmMode.Unsynced:
                overrides["Unsynced"] = "true";
                break;
            case FarmMode.DutySupport:
                overrides["dutyModeEnum"] = "Support";
                break;
            case FarmMode.Trust:
                overrides["dutyModeEnum"] = "Trust";
                break;
        }

        return overrides;
    }

    private static bool TryBuildOverridesFromReflection(out Dictionary<string, string> overrides) {
        overrides = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        var configType = GetConfigType();
        if (configType is null)
            return false;

        const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
        var boolFields = configType.GetFields(flags)
            .Where(f => f.FieldType == typeof(bool))
            .Select(f => (Field: f, Name: CleanConfigName(f.Name)))
            .Where(x => !x.Name.Equals("Version", StringComparison.OrdinalIgnoreCase))
            .OrderBy(x => x.Field.MetadataToken)
            .ToList();

        if (boolFields.Count == 0)
            return false;

        var start = boolFields.FindIndex(x => x.Name.Equals(SectionStart, StringComparison.OrdinalIgnoreCase));
        var end = boolFields.FindIndex(x => x.Name.Equals(SectionEnd, StringComparison.OrdinalIgnoreCase));
        if (start < 0 || end < 0 || end < start)
            return false;

        for (var i = start; i <= end; i++)
            overrides[boolFields[i].Name] = "false";

        foreach (var key in GlamourFarmEnable)
            overrides[key] = "true";

        return true;
    }

    private static Type? GetConfigType()
        => AppDomain.CurrentDomain.GetAssemblies()
            .FirstOrDefault(a => a.GetName().Name?.Equals("AutoDuty", StringComparison.OrdinalIgnoreCase) == true)
            ?.GetType("AutoDuty.Windows.Configuration");

    // ConfigHelper.FindConfig
    private static string CleanConfigName(string fieldName)
        => fieldName.Replace(">k__BackingField", "", StringComparison.Ordinal).Replace("<", "", StringComparison.Ordinal);
}
