using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.Game.UI;
using System.Threading;
using System.Threading.Tasks;

namespace GlamourLog.Services;

internal sealed class CatalogService : IPluginService, IDisposable {
    internal ReadOnlyCollection<GlamourSet> GlamourSets { get; private set; } = new ReadOnlyCollection<GlamourSet>([]);
    internal Dictionary<string, List<GlamourSet>> GlamourSetsByCategory { get; } = [];
    internal HashSet<uint> ArmoireItemIds { get; private set; } = [];
    internal HashSet<uint> MirageOutfitPieceIds { get; private set; } = [];
    internal HashSet<uint> MirageSetTokenIds { get; private set; } = [];
    private HashSet<uint> _costCurrencyItemIds = [];
    private IReadOnlyList<uint> _currencyFilterAll = [];
    private Dictionary<string, IReadOnlyList<uint>> _currencyFilterByDisplayCategory = [];
    private Dictionary<uint, HashSet<uint>> _setFilterCurrencyIdsBySetId = [];
    private Dictionary<SetModelSignature, List<GlamourSet>> _sharedModelGroups = [];
    private Dictionary<ItemModelInfo, List<uint>> _sharedModelItemGroups = [];

    private readonly Lock _glamourDataLock = new();
    private readonly Lock _catalogRequestLock = new();
    private Catalog _catalog = Catalog.CreateEmptyStub();
    private volatile bool _catalogBuilt;
    private int _pendingListRefresh; // ui picks this up next frame after a background rebuild
    private CancellationTokenSource? _catalogCts;

    private readonly UnobtainableService _unobtainable;

    internal int DataVersion { get; private set; }

    public CatalogService() {
        _unobtainable = UnobtainableService.Get();
        Svc.ClientState.Login += OnClientLogin;
        _unobtainable.Changed += OnUnobtainableChanged;

        if (Svc.ClientState.IsLoggedIn)
            InvalidateCatalog();
    }

    public void Dispose() {
        Svc.ClientState.Login -= OnClientLogin;
        _unobtainable.Changed -= OnUnobtainableChanged;
        _catalogCts?.Cancel();
        _catalogCts?.Dispose();
        _catalogCts = null;
        lock (_glamourDataLock) {
            _catalogBuilt = false;
            _costCurrencyItemIds = [];
            _currencyFilterAll = [];
            _currencyFilterByDisplayCategory = [];
            _setFilterCurrencyIdsBySetId = [];
        }
    }

    private void OnClientLogin() => InvalidateCatalog();
    private void OnUnobtainableChanged() {
        if (_catalogBuilt)
            RefreshUnobtainable();
    }
    internal void OnArmoireChanged() => InvalidateCatalog();

    private void InvalidateCatalog() {
        lock (_glamourDataLock)
            _catalogBuilt = false;
        RequestCatalogBuild();
    }

    private void RequestCatalogBuild() {
        if (_catalogBuilt)
            return;
        lock (_catalogRequestLock) {
            if (_catalogBuilt)
                return;
            _catalogCts?.Cancel();
            _catalogCts?.Dispose();
            _catalogCts = new CancellationTokenSource();
            var token = _catalogCts.Token;
            _ = Task.Run(async () => {
                static unsafe bool CurrencyManagerReady() => CurrencyManager.Instance() != null; // unnecessary unsafe modifier my fucking ass, microslop
                // crafting currency ids aren't available until this shows up after login
                while (!CurrencyManagerReady())
                    await Task.Delay(1000, token);
                RunCatalogBuild(token);
            }, token);
        }
    }

    private unsafe void RunCatalogBuild(CancellationToken token) {
        try {
            token.ThrowIfCancellationRequested();
            var pvpSeries = PvPProfile.Instance()->Series;
            var built = CatalogBuilder.Run();
            token.ThrowIfCancellationRequested();

            lock (_glamourDataLock) {
                token.ThrowIfCancellationRequested();
                _catalog = built.Catalog;
                ArmoireItemIds = built.ArmoireItemIds;
                GlamourSets = built.Sets;
                MirageOutfitPieceIds = [.. GlamourSets.Where(s => !s.NonSetCabinetPiece).SelectMany(s => s.Items)];
                MirageSetTokenIds = [.. GlamourSets.Where(s => !s.NonSetCabinetPiece).Select(s => s.ItemId)];
                RebuildCategoryMapUnlocked();
                _sharedModelGroups = GlamourSets.GroupBy(s => s.ModelSignature).ToDictionary(g => g.Key, g => g.OrderBy(s => s.ItemId).ToList());
                _sharedModelItemGroups = CatalogBuilder.BuildSharedModelItemGroups(GlamourSets.SelectMany(s => s.Items));
                LogMissingMirageSets();
                DataVersion++;
                _catalogBuilt = true;
            }
            RebuildCostCurrencyIndexes();
            Interlocked.Exchange(ref _pendingListRefresh, 1);
            WindowsService.Get().RefreshLogWindow();
        }
        catch (OperationCanceledException) {
            // cancelled by logout / disable / superseded build
        }
        catch (Exception ex) {
            Svc.Log.Error(ex, $"{nameof(CatalogService)} catalog build");
        }
    }

    private void RefreshUnobtainable() {
        lock (_glamourDataLock) {
            if (!_catalogBuilt)
                return;
            GlamourSets = CatalogBuilder.ReapplyUnobtainable(GlamourSets);
            RebuildCategoryMapUnlocked();
            _sharedModelGroups = GlamourSets.GroupBy(s => s.ModelSignature).ToDictionary(g => g.Key, g => g.OrderBy(s => s.ItemId).ToList());
            DataVersion++;
        }
        Interlocked.Exchange(ref _pendingListRefresh, 1);
        WindowsService.Get().RefreshLogWindow();
    }

    private void RebuildCategoryMapUnlocked() {
        GlamourSetsByCategory.Clear();
        foreach (var group in GlamourSets.GroupBy(s => _catalog.GetDisplayCategoryName(s.CategoryName)))
            GlamourSetsByCategory[group.Key] = [.. group];
    }

    internal bool CatalogReady => _catalogBuilt;

    internal bool IsKnownCostCurrency(uint itemId) => itemId != 0 && _catalogBuilt && _costCurrencyItemIds.Contains(itemId);

    // currencies w/ cost > 1, null = all
    internal IReadOnlyList<uint> GetCurrencyFilterItemIds(string? displayCategoryName) {
        if (!_catalogBuilt)
            return [];
        if (displayCategoryName is null)
            return _currencyFilterAll;
        return _currencyFilterByDisplayCategory.TryGetValue(displayCategoryName, out var list) ? list : [];
    }

    internal bool SetUsesCurrencyFilter(GlamourSet set, uint currencyItemId) => currencyItemId != 0 && _setFilterCurrencyIdsBySetId.TryGetValue(set.ItemId, out var ids) && ids.Contains(currencyItemId);
    internal bool IsMirageOutfitPiece(uint itemId) => itemId != 0 && _catalogBuilt && MirageOutfitPieceIds.Contains(itemId);
    internal bool TryConsumePendingListRefresh() => Interlocked.Exchange(ref _pendingListRefresh, 0) != 0;
    internal void NotifyOwnershipChanged() => WindowsService.Get().RefreshLogWindow();

    internal IReadOnlyList<OutfitCategory> OutfitCategories => _catalog.ClassifiableCategories; // excludes synthetic (non rule-matched) categories
    internal OutfitCategory UncategorizedTab => _catalog.UncategorizedBucket;
    internal OutfitCategory MiscArmoireTab => _catalog.MiscArmoireBucket;

    // synthetic tabs don't have a preferred currency to pin costs to
    internal string? GetCategoryForPreferredCost(GlamourSet set) {
        if (set.CategoryName is null)
            return null;
        lock (_glamourDataLock) {
            if (set.CategoryName == _catalog.UncategorizedBucket.Name
                || set.CategoryName == _catalog.MiscArmoireBucket.Name
                || set.NonSetCabinetPiece)
                return null;
            return set.CategoryName;
        }
    }

    // item ids the sources panel should look up (set pieces + their main cost currencies for the current filter)
    internal IReadOnlyCollection<uint> GetSourceScopeItemIds(GlamourSet set, uint? filterPieceId) {
        lock (_glamourDataLock)
            return [.. BuildSourceScopeItemIds(set, filterPieceId)];
    }

    private HashSet<uint> BuildSourceScopeItemIds(GlamourSet set, uint? filterPieceId) {
        var cat = GetCategoryForPreferredCost(set);
        var itemIds = new HashSet<uint>();
        var pieces = filterPieceId is { } only ? (IEnumerable<uint>)[only] : set.Items;
        foreach (var pieceId in pieces) {
            itemIds.Add(pieceId);
            foreach (var c in GetPrimaryItemCosts(pieceId, cat))
                if (c.ItemId != 0)
                    itemIds.Add(c.ItemId);
        }
        return itemIds;
    }

    // prefer the currency that put this set in its current tab (falls back to all listed costs)
    internal List<(uint ItemId, uint Amount)> GetPrimaryItemCosts(uint itemId, string? categoryNameForDiscriminator) {
        var costs = Svc.Items.GetItemCosts(itemId);
        if (costs.Count == 0)
            return [];
        if (!string.IsNullOrEmpty(categoryNameForDiscriminator)) {
            lock (_glamourDataLock) {
                var cat = _catalog.ClassifiableCategories.FirstOrDefault(c => c.Name == categoryNameForDiscriminator);
                if (cat is not null) {
                    var late = cat.Discriminator.LateCostCurrencyItemIds;
                    if (late.Count > 0) {
                        var pinnedLate = costs.Where(c => late.Contains(c.ItemId)).ToList();
                        if (pinnedLate.Count > 0)
                            return pinnedLate;
                    }
                    if (cat.Discriminator.PieceOrCostItemIds is { Count: > 0 } pieceSet) {
                        var pinnedPiece = costs.Where(c => pieceSet.Contains(c.ItemId)).ToList();
                        if (pinnedPiece.Count > 0)
                            return pinnedPiece;
                    }
                }
            }
        }
        return [.. costs];
    }

    internal IReadOnlyList<GlamourSet> GetSharedModelSiblings(GlamourSet set) {
        lock (_glamourDataLock) {
            if (!_sharedModelGroups.TryGetValue(set.ModelSignature, out var group) || group.Count <= 1)
                return [];
            return [.. group.Where(s => s.ItemId != set.ItemId)];
        }
    }

    internal IReadOnlyList<uint> GetSharedModelItemSiblings(uint itemId) {
        lock (_glamourDataLock)
            return GetSharedModelItemSiblingsUnlocked(itemId, _sharedModelItemGroups);
    }

    internal IReadOnlyList<GlamourSet> GetPartialSharedModelSetSiblings(GlamourSet set) {
        lock (_glamourDataLock) {
            var results = new List<GlamourSet>();
            var seen = new HashSet<GlamourSet>();
            foreach (var pieceId in set.Items) {
                foreach (var siblingId in GetSharedModelItemSiblingsUnlocked(pieceId, _sharedModelItemGroups)) {
                    var siblingSet = FindCatalogSetForItemUnlocked(siblingId);
                    if (siblingSet is null || ReferenceEquals(siblingSet, set) || !seen.Add(siblingSet))
                        continue;
                    results.Add(siblingSet);
                }
            }
            return results;
        }
    }

    private static IReadOnlyList<uint> GetSharedModelItemSiblingsUnlocked(uint itemId, Dictionary<ItemModelInfo, List<uint>> itemGroups) {
        var row = Item.GetRow(itemId);
        var slot = row.EquipSlot;
        ItemModelInfo model = itemId;
        if (!itemGroups.TryGetValue(model, out var group) || group.Count <= 1)
            return [];
        return [.. group.Where(id => id != itemId && Item.GetRow(id).EquipSlot == slot)];
    }

    internal GlamourSet? FindCatalogSetForItem(uint itemId) {
        lock (_glamourDataLock)
            return FindCatalogSetForItemUnlocked(itemId);
    }

    // prefer a standalone armoire entry over the first matching outfit that contains the piece
    private GlamourSet? FindCatalogSetForItemUnlocked(uint itemId) {
        foreach (var set in GlamourSets) {
            if (set.NonSetCabinetPiece && set.ItemId == itemId)
                return set;
        }
        return GlamourSets
            .Where(s => !s.NonSetCabinetPiece && s.Items.Contains(itemId))
            .OrderBy(s => s.ItemId)
            .FirstOrDefault();
    }

    internal string GetCategoryBucketKey(GlamourSet set) {
        lock (_glamourDataLock)
            return _catalog.GetDisplayCategoryName(set.CategoryName);
    }

    private void RebuildCostCurrencyIndexes() {
        var allKnown = new HashSet<uint>();
        var allFilter = new HashSet<uint>();
        var byDisplay = new Dictionary<string, HashSet<uint>>();
        var bySetId = new Dictionary<uint, HashSet<uint>>();

        foreach (var set in GlamourSets) {
            var preferred = GetCategoryForPreferredCost(set);
            var display = GetCategoryBucketKey(set);
            var setFilterIds = new HashSet<uint>();
            foreach (var pieceId in set.Items) {
                foreach (var (costId, amount) in GetPrimaryItemCosts(pieceId, preferred)) {
                    if (costId == 0)
                        continue;
                    allKnown.Add(costId);
                    if (amount <= 1)
                        continue;
                    setFilterIds.Add(costId);
                    allFilter.Add(costId);
                    if (!byDisplay.TryGetValue(display, out var catIds))
                        byDisplay[display] = catIds = [];
                    catIds.Add(costId);
                }
            }
            if (setFilterIds.Count > 0)
                bySetId[set.ItemId] = setFilterIds;
        }

        static List<uint> SortedByName(HashSet<uint> ids)
            => [.. ids.OrderBy(id => Item.GetRow(id).Name.ToString(), StringComparer.Ordinal)];

        _costCurrencyItemIds = allKnown;
        _currencyFilterAll = SortedByName(allFilter);
        _currencyFilterByDisplayCategory = byDisplay.ToDictionary(kv => kv.Key, kv => (IReadOnlyList<uint>)SortedByName(kv.Value));
        _setFilterCurrencyIdsBySetId = bySetId;
    }

    // in case I somehow miss a set
    private void LogMissingMirageSets() {
        try {
            var sourceRowIds = MirageStoreSetItem.Where(r => r.RowId > 0 && r.Items.Any(i => i.RowId > 0)).Select(r => r.RowId).ToHashSet();
            var classifiedRowIds = GlamourSets.Select(s => s.ItemId).ToHashSet();
            if (classifiedRowIds.Count >= sourceRowIds.Count)
                return;

            // TODO: dump full list not just some
            var missing = sourceRowIds.Where(id => !classifiedRowIds.Contains(id)).OrderBy(id => id).ToList();
            var preview = string.Join(", ", missing.Take(80));
            var suffix = missing.Count > 80 ? " ..." : string.Empty;
            Svc.Log.Warning($"[{nameof(CatalogService)}] Coverage gap: source={sourceRowIds.Count}, classified={classifiedRowIds.Count}, missing={missing.Count}. Missing MirageStoreSetItem rowIds: {preview}{suffix}");
        }
        catch (Exception ex) {
            Svc.Log.Error(ex, $"[{nameof(CatalogService)}] mirage coverage diagnostics");
        }
    }
}
