using Dalamud.Game.Text.SeStringHandling;
using Lumina.Text.ReadOnly;

namespace GlamourLog;

/// <summary>
/// Theme-aware SeString builders for guide text.
/// The default client "highlight"/"emphasis"/"footnote" colors are designed for dark panels;
/// in the <see cref="UiTheme.DarkText"/> scheme (used on light game themes) they become unreadable,
/// so those spans fall back to the themed body color.
/// </summary>
internal static class GuideSeString {
    private static bool IsDarkTheme => Configuration.C.Theme == UiTheme.DarkText;

    /// <summary>Section-header text (drawn by KamiToolKit with a fixed color): force a light color on its dark pill.</summary>
    public static ReadOnlySeString Header(string text) {
        if (!IsDarkTheme)
            return text;
        return new ReadOnlySeString(new SeStringBuilder()
            .AddUiForeground(text, 8)
            .Encode());
    }

    public static SeStringBuilder HighlightStyled(this SeStringBuilder builder, string text)
        => IsDarkTheme ? builder.AddText(text) : builder.Highlight(text);

    public static SeStringBuilder EmphasisStyled(this SeStringBuilder builder, string text)
        => IsDarkTheme ? builder.AddText(text) : builder.Emphasis(text);

    public static SeStringBuilder FootnoteStyled(this SeStringBuilder builder, string text)
        => IsDarkTheme ? builder.AddText(text) : builder.Footnote(text);
}
