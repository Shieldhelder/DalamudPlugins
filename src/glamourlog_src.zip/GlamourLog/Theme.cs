using FFXIVClientStructs.FFXIV.Component.GUI;

namespace GlamourLog;

/// <summary>
/// Theme-aware text flag helpers. The game's Emboss/Edge shadows are tuned for dark panels; on the
/// <see cref="UiTheme.DarkText"/> scheme (light game theme) they turn near-black text into a muddy
/// embossed blob, so they are dropped there.
/// </summary>
internal static class Theme {
    public static TextFlags Emboss
        => Configuration.C.Theme == UiTheme.DarkText ? 0 : TextFlags.Emboss;

    public static TextFlags Edge
        => Configuration.C.Theme == UiTheme.DarkText ? 0 : TextFlags.Edge;
}
