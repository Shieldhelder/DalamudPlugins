using FFXIVClientStructs.FFXIV.Component.GUI;
using GlamourLog.Nodes;
using GlamourLog.Services;
using KamiToolKit.BaseTypes;
using KamiToolKit.Nodes;

namespace GlamourLog;

internal unsafe class FilterWindow : NativeAddon {
    public const float WindowWidth = 456f;
    public const float WindowHeight = 358f;
    private readonly List<CheckboxNode> _checkboxes = [];
    private TextButtonNode? _okButton;
    private bool _hasPendingScreenOrigin;
    private Vector2 _pendingScreenOrigin;

    public void OpenOrToggleNear(Vector2 screenTopLeft) {
        if (IsOpen) {
            Close();
            return;
        }

        _pendingScreenOrigin = ClampFilterWindowTopLeft(screenTopLeft);
        _hasPendingScreenOrigin = true;
        Open();
    }

    public void CloseIfOpen() {
        if (IsOpen)
            Close();
    }

    public static Vector2 ClampFilterWindowTopLeft(Vector2 origin) {
        var screen = AtkStage.Instance()->ScreenSize;
        var maxX = Math.Max(0f, screen.Width - WindowWidth);
        var maxY = Math.Max(0f, screen.Height - WindowHeight);
        return new Vector2(
            Math.Clamp(origin.X, 0f, maxX),
            Math.Clamp(origin.Y, 0f, maxY));
    }

    protected override void OnSetup(AtkUnitBase* addon, Span<AtkValue> atkValueSpan) {
        if (_hasPendingScreenOrigin) {
            SetWindowPosition(_pendingScreenOrigin);
            _hasPendingScreenOrigin = false;
        }

        _checkboxes.ForEach(c => c.Dispose());
        _checkboxes.Clear();
        _okButton?.Dispose();
        _okButton = null;

        var start = ContentStartPosition;
        var rowWidth = ContentSize.X - 16f;
        var x = start.X + 8f;
        var y = start.Y + 8f;
        const float rowHeight = 20f;

        void AddCheckbox(string label, string tooltip, Func<Configuration, bool> read, Action<Configuration> flip) {
            CheckboxNode cb = null!;
            cb = new CheckboxNode {
                Position = new Vector2(x, y),
                Size = new Vector2(rowWidth, rowHeight),
                String = label,
                TextTooltip = tooltip,
                IsChecked = read(C),
                OnClick = _ => {
                    flip(C);
                    cb.IsChecked = read(C);
                    C.Save();
                    CatalogService.Get().NotifyOwnershipChanged();
                },
            };
            y += rowHeight + 2f;
            _checkboxes.Add(cb);
            cb.AttachNode(this);
        }

        AddCheckbox(
            Loc.T("Hide completed", "隐藏已完成"),
            Loc.T("Hide sets where every piece is owned", "隐藏所有部件都已拥有的套装"),
            c => c.HideCompleted,
            c => c.HideCompleted ^= true);
        AddCheckbox(
            Loc.T("Hide incompatible items", "隐藏不兼容部件"),
            Loc.T("Hides all sets whose items are unwearable due to race or sex restrictions", "隐藏因种族或性别限制而无法穿着的套装"),
            c => c.HideIncompatible,
            c => c.HideIncompatible ^= true);
        AddCheckbox(
            Loc.T("Hide unobtainable", "隐藏无法获取"),
            Loc.T("Hide sets that cannot currently be obtained (seasonal/old series). Completed sets still show.", "隐藏当前无法获取的套装（季节活动/旧系列）。已完成的套装仍会显示。"),
            c => c.HideUnobtainable,
            c => c.HideUnobtainable ^= true);
        AddCheckbox(
            Loc.T("Hide mogstation", "隐藏商城物品"),
            Loc.T("Hide sets and pieces that come from the mogstation", "隐藏来自商城（Mog Station）的套装与部件"),
            c => c.HideMogstation,
            c => c.HideMogstation ^= true);
        AddCheckbox(
            Loc.T("Hide uncontributable", "隐藏无法放入"),
            Loc.T("Hide sets where no piece is in your inventory to contribute to the set", "隐藏背包中没有部件可供存入的套装"),
            c => c.HideUnready,
            c => c.HideUnready ^= true);
        AddCheckbox(
            Loc.T("Hide shared models", "隐藏同模套装"),
            Loc.T("Hide outfits that share the same models. Will still show any sets that are started or completed.", "隐藏外观相同（同模）的套装。已开始或已完成的套装仍会显示。"),
            c => c.HideSharedModels,
            c => c.HideSharedModels ^= true);
        AddCheckbox(
            Loc.T("Show only completed", "仅显示已完成"),
            Loc.T("Show only sets where every piece is owned", "仅显示所有部件都已拥有的套装"),
            c => c.ShowOnlyCompleted,
            c => c.ShowOnlyCompleted ^= true);
        AddCheckbox(
            Loc.T("Show only affordable sets", "仅显示可负担套装"),
            Loc.T("Show only sets where you can afford the currency cost of all pieces", "仅显示当前货币足以购买全部部件的套装"),
            c => c.HideUnaffordable,
            c => c.HideUnaffordable ^= true);
        AddCheckbox(
            Loc.T("Show only tradeable", "仅显示可交易"),
            Loc.T("Show only sets whose pieces can be bought on the marketboard or traded", "仅显示部件可在板子上购买或可通过交易获得的套装"),
            c => c.HideNoMarketboard,
            c => c.HideNoMarketboard ^= true);
        AddCheckbox(
            Loc.T("Show only started", "仅显示已开始"),
            Loc.T("Show only sets that are partially completed", "仅显示已部分完成的套装"),
            c => c.HideNonPartials,
            c => c.HideNonPartials ^= true);
        AddCheckbox(
            Loc.T("Show only misplaced", "仅显示放错位置"),
            Loc.T("Show only sets that have pieces in the dresser that could be stored in the armoire", "仅显示有部件放在投影台中、其实可以存入收藏柜的套装"),
            c => c.ShowOnlyMisplaced,
            c => c.ShowOnlyMisplaced ^= true);

        const float okWidth = 150f;
        const float okHeight = 28f;
        var bottomPad = 10f;
        var checkboxCount = 11;
        var checklistBottom = start.Y + 8f + checkboxCount * (rowHeight + 2f);
        var okY = start.Y + ContentSize.Y - okHeight - bottomPad;
        var minOkY = checklistBottom + 8f;
        if (okY < minOkY)
            okY = minOkY;

        var okX = x + (rowWidth - okWidth) * 0.5f;

        _okButton = new TextButtonNode {
            Position = new Vector2(okX, okY),
            Size = new Vector2(okWidth, okHeight),
            String = Addon.GetRow(1).Text,
            OnClick = Close,
        };
        _okButton.LabelNode.FontType = FontType.Axis;
        _okButton.LabelNode.FontSize = 12;
        _okButton.LabelNode.LineSpacing = 12;
        _okButton.LabelNode.TextColor = ColourPalette.ControlText;
        _okButton.AttachNode(this);
    }

    protected override void OnUpdate(AtkUnitBase* addon) {
        if (_checkboxes.Count < 11) {
            base.OnUpdate(addon);
            return;
        }

        _checkboxes[0].IsChecked = C.HideCompleted;
        _checkboxes[1].IsChecked = C.HideIncompatible;
        _checkboxes[2].IsChecked = C.HideUnobtainable;
        _checkboxes[3].IsChecked = C.HideMogstation;
        _checkboxes[4].IsChecked = C.HideUnready;
        _checkboxes[5].IsChecked = C.HideSharedModels;
        _checkboxes[6].IsChecked = C.ShowOnlyCompleted;
        _checkboxes[7].IsChecked = C.HideUnaffordable;
        _checkboxes[8].IsChecked = C.HideNoMarketboard;
        _checkboxes[9].IsChecked = C.HideNonPartials;
        _checkboxes[10].IsChecked = C.ShowOnlyMisplaced;

        base.OnUpdate(addon);
    }

    protected override void OnFinalize(AtkUnitBase* addon) {
        // don't dispose nodes here
        _checkboxes.Clear();
        _okButton = null;
        base.OnFinalize(addon);
    }
}
