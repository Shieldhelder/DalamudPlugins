using FFXIVClientStructs.FFXIV.Client.UI.Agent;
using KamiToolKit.BaseTypes;
using ContextMenu = KamiToolKit.ContextMenu.ContextMenu;

namespace GlamourLog.Windows.ContextMenus;

internal static unsafe class SetContextMenu {
    public static void Open(NativeAddon owner, GlamourSet set, ContextMenu menu) {
        GlamourLogAgentContext.AttachContextMenuTo(owner);
        menu.Clear();
        menu.AddItem($"{Addon.GetRow(2426).Text} ({Addon.GetRow(1043).Text})", () => {
            AgentTryon.Instance()->TryOnSilent(set.Items.ToArray());
        });
        menu.Open();
    }
}
