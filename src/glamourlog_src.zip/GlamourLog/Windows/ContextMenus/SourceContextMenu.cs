using clib.TaskSystem;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;
using GlamourLog.Services;
using KamiToolKit.BaseTypes;
using System.Threading.Tasks;
using ContextMenu = KamiToolKit.ContextMenu.ContextMenu;

namespace GlamourLog.Windows.ContextMenus;

internal static class SourceContextMenu {
    public static unsafe void Open(NativeAddon owner, uint cfcId, SourceNavigateTarget? navigateTarget, ContextMenu menu) {
        if (cfcId == 0 && navigateTarget is null)
            return;

        GlamourLogAgentContext.AttachContextMenuTo(owner);
        menu.Clear();

        if (navigateTarget is { TerritoryTypeId: not 0 and var territoryId, WorldPosition: var pos } && Svc.Interface.IsPluginLoaded("vnavmesh")) {
            menu.AddItem(Loc.T("Navigate to location", "前往地点 (Vnavmesh)"), () => {
                Svc.Automation.Start(new NavTo(territoryId, pos));
            });
        }

        if (cfcId != 0) {
            // 7.0+ (Dawntrail, ExVersion >= 5) duties cannot be run unsynced.
            var seventhPlus = ContentFinderCondition.GetRowRef(cfcId) is { IsValid: true, Value.TerritoryType: { Value: var territoryType } }
                              && territoryType.ExVersion.RowId >= 5;

            menu.AddItem(Addon.GetRow(15890).Text, () => AgentContentsFinder.Instance()->OpenRegularDuty(cfcId));
            menu.AddItem($"{Addon.GetRow(9663).Text} ({Addon.GetRow(1145).Text})", () => { // Queue (Level Sync)
                if (ContentFinderCondition.GetRowRef(cfcId) is { IsValid: true, Value: var cfc })
                    cfc.QueueDuty(levelSync: true);
            });
            if (!seventhPlus) {
                menu.AddItem($"{Addon.GetRow(9663).Text} ({Addon.GetRow(10008).Text})", () => { // Queue (Unrestricted Party)
                    if (ContentFinderCondition.GetRowRef(cfcId) is { IsValid: true, Value: var cfc })
                        cfc.QueueDuty(levelSync: false);
                });
            }
            if (Svc.Interface.IsPluginLoaded("AutoDuty")) {
                if (!seventhPlus)
                    menu.AddItem(Loc.T("AutoDuty (Unsynced)", "AutoDuty (解除限制)"), () => AutoDutyIpc.Get().FarmOutfit(cfcId, AutoDutyIpc.FarmMode.Unsynced));
                menu.AddItem(Loc.T("AutoDuty (Duty Support)", "AutoDuty (副本辅助器)"), () => AutoDutyIpc.Get().FarmOutfit(cfcId, AutoDutyIpc.FarmMode.DutySupport));
                menu.AddItem(Loc.T("AutoDuty (Trust)", "AutoDuty (亲信战友)"), () => AutoDutyIpc.Get().FarmOutfit(cfcId, AutoDutyIpc.FarmMode.Trust));
            }
        }

        menu.Open();
    }

    private sealed class NavTo(uint territoryTypeId, Vector3 worldPosition) : TaskBase {
        protected override async Task Execute()
            => await MoveTo(territoryTypeId, worldPosition, MovementConfig.Everything);
    }
}
