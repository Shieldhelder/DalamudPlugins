using Dalamud.Game.Text.SeStringHandling;

namespace GlamourLog.Windows.GuideWindow;

public partial class GuideWindow {
    private static Page TweaksLootWindow => new() {
        CategoryTitle = Loc.T("Tweaks", "辅助功能"),
        SubCategoryTitle = Loc.T("Loot Window", "战利品窗口"),
        Blocks =
        [
            new GuideTextBlock(
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .Append(Loc.T("When the loot window is open, a badge is displayed on item icons for glam pieces you do not already own.", "战利品窗口打开时，会在你尚未拥有的幻化部件图标上显示标记。"))
                        .Encode())),
            new IconExampleBlock(
                IconExampleKind.Armoire,
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .HighlightStyled(Loc.T("Armoire badge", "收藏柜标记"))
                        .Append(Loc.T(" is shown on unowned armoire-eligible items.", " 显示于未拥有、可放入收藏柜的物品上。"))
                        .Encode())),
            new IconExampleBlock(
                IconExampleKind.Dresser,
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .HighlightStyled(Loc.T("Dresser badge", "投影台标记"))
                        .Append(Loc.T(" is shown on unowned, non-armoire outfit pieces.", " 显示于未拥有且不能放入收藏柜的套装部件上。"))
                        .Encode())),
        ],
    };
}
