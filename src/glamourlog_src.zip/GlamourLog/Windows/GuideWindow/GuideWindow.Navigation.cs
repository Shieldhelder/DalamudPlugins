namespace GlamourLog.Windows.GuideWindow;

public partial class GuideWindow {
    private static CategoryNav[] NavCategories
        => [
            new(Loc.T("Guide", "指南"), [Icons, GuideCounters, Integrations]),
            new(Loc.T("Tweaks", "辅助功能"), [TweaksArmoire, TweaksDresser, TweaksChatAlerts, TweaksLootWindow]),
            new(Loc.T("Export", "导出"), [ExportData]),
            new(Loc.T("Settings", "设置"), [SettingsLogWindow]),
            #if DEBUG
            new("Debug", [DebugCircleButtons]),
            #endif
    ];
}

internal sealed record CategoryNav(string Title, Page[] Pages);
