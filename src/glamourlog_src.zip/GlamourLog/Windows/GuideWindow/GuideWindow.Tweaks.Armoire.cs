using Dalamud.Game.Text.SeStringHandling;
using GlamourLog.Nodes.GuideWindow;
using KamiToolKit.Enums;

namespace GlamourLog.Windows.GuideWindow;

public partial class GuideWindow {
    private static Page TweaksArmoire => new() {
        CategoryTitle = Loc.T("Tweaks", "辅助功能"),
        SubCategoryTitle = Loc.T("Armoire", "收藏柜"),
        Blocks =
        [
            new GuideTextBlock(
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .Append(Loc.T("GlamourLog adds two buttons next to the category arrows on the armoire window.", "Glamour Log 会在收藏柜窗口的分类箭头旁添加两个按钮。"))
                        .Encode())),
            new CircleButtonExampleBlock(
                CircleButtonIcon.GearCog,
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .HighlightStyled(Loc.T("Filters", "筛选"))
                        .Append(Loc.T(" opens a filter window to hide items that match some criteria:", " 按钮可打开筛选窗口，隐藏符合某些条件的物品："))
                        .Encode())),
            new GuideTextBlock(
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .EmphasisStyled(Loc.T("Hide already deposited items", "隐藏已存放物品"))
                        .Encode()),
                TextLeftInset: Constants.IconTextLeft),
            new GuideTextBlock(
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .EmphasisStyled(Loc.T("Hide items in gearsets", "隐藏幻化套装物品"))
                        .Encode()),
                TextLeftInset: Constants.IconTextLeft),
            new CircleButtonExampleBlock(
                CircleButtonIcon.Chest,
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .HighlightStyled(Loc.T("Store all", "全部存入"))
                        .Append(Loc.T(" stores all eligible items from your inventory into the armoire. Ignores items in gearsets.", " 按钮会把背包中所有符合条件的物品全部存入收藏柜。属于幻化套装的物品将被忽略。"))
                        .Encode())),
        ],
    };
}
