using Dalamud.Game.Text.SeStringHandling;

namespace GlamourLog.Windows.GuideWindow;

public partial class GuideWindow {
    private static Page Icons => new() {
        CategoryTitle = Loc.T("Guide", "指南"),
        SubCategoryTitle = Loc.T("Icons", "图标"),
        Blocks =
        [
            new IconExampleBlock(
                IconExampleKind.Checkmark,
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder().HighlightStyled(Loc.T("Checkmark", "对勾"))
                    .Append(Loc.T(" is shown on a set icon when every piece is in your glamour dresser or armoire. Inventory does not count.", "在套装全部部件都已存入投影台或收藏柜时，显示于套装图标上。只放在背包中不计入。")).Encode())),
            new IconExampleBlock(
                IconExampleKind.Unobtainable,
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder().HighlightStyled(Loc.T("Unobtainable", "无法获取"))
                    .Append(Loc.T(" is shown on a set that cannot currently be obtained, e.g. a seasonal event set. These sets are excluded from the completion counters.", "显示于当前无法获取的套装，例如季节活动套装。这类套装不计入完成度计数。")).Encode())),
            new IconExampleBlock(
                IconExampleKind.FadedDresser,
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder().HighlightStyled(Loc.T("Faded Dresser badge", "淡化投影台标记"))
                    .Append(Loc.T(" is shown on a complete set or owned piece when the item is in your dresser ", "当部件存放在投影台中但尚未编入套装时，显示于已完成套装或已拥有部件上的标记，表示该物品位于投影台 "))
                    .EmphasisStyled(Loc.T("not", "而未"))
                    .Append(Loc.T(" as part of a set.", "作为套装的一部分。")).Encode())),
            new IconExampleBlock(
                IconExampleKind.Dresser,
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder().HighlightStyled(Loc.T("Dresser badge", "投影台标记"))
                    .Append(Loc.T(" shown on a complete set or owned piece when the item is in your dresser as part of a set.", "当部件已作为套装的一部分存放在投影台中时，显示于已完成套装或已拥有部件上的标记。")).Encode())),
            new IconExampleBlock(
                IconExampleKind.Armoire,
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder().HighlightStyled(Loc.T("Armoire badge", "收藏柜标记"))
                    .Append(Loc.T(" is shown on a complete set or owned piece when the item is in your armoire.", "当部件存放在收藏柜中时，显示于已完成套装或已拥有部件上的标记。")).Encode())),
            new IconExampleBlock(
                IconExampleKind.WarningDresser,
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder().HighlightStyled(Loc.T("Dresser warning", "投影台警示"))
                    .Append(Loc.T(" is shown if the item is currently stored in the dresser but could be stored in the armoire. Also applies to sets.", "当部件当前存放在投影台、但其实可以存入收藏柜时显示。同样适用于整套套装。")).Encode())),
        ],
    };
}
