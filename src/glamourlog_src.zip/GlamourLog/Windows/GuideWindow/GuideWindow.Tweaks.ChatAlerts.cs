using Dalamud.Game.Text.SeStringHandling;

namespace GlamourLog.Windows.GuideWindow;

public partial class GuideWindow {
    private static Page TweaksChatAlerts => new() {
        CategoryTitle = Loc.T("Tweaks", "辅助功能"),
        SubCategoryTitle = Loc.T("Chat Alerts", "聊天提醒"),
        Blocks =
        [
            new GuideTextBlock(
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .Append(Loc.T("When you loot an item that belongs to a glamour set, outfit progress is appended to the loot notice in chat.", "当你拾取到属于某个幻化套装的物品时，会在聊天中的拾取提示后附加该套装的收集进度。")).Encode())),
            new GuideTextBlock(
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .Append(Loc.T("You obtain a ", "你获得了 "))
                        .Append(SeString.CreateItemLink(32597))
                        .Append(Loc.T(". 3/5 of the set ", "。套装 "))
                        .Append(SeString.CreateItemLink(51550))
                        .Append(Loc.T("!", " 收集进度 3/5！"))
                        .Encode())),
            new GuideTextBlock(
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .Append(Loc.T("You obtain a ", "你获得了 "))
                        .Append(SeString.CreateItemLink(32622))
                        .Append(Loc.T(". The final piece of ", "。这是套装 "))
                        .Append(SeString.CreateItemLink(51550))
                        .Append(Loc.T("!", " 的最后一件！"))
                        .Encode())),
            new GuideTextBlock(
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .Append(Loc.T("You obtain a ", "你获得了 "))
                        .Append(SeString.CreateItemLink(50933))
                        .Append(Loc.T(". This item can go in your armoire!", "。这件物品可以放入收藏柜！"))
                        .Encode())),
            new GuideTextBlock(
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .Append(Loc.T("If you already own the item in storage, the loot notice is left unchanged.", "如果你已在收藏中拥有该物品，聊天中的拾取提示将保持不变。"))
                        .Encode())),
        ],
    };
}
