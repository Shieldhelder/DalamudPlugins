using Dalamud.Bindings.ImGui;
using Dalamud.Game.Text.SeStringHandling;
using GlamourLog.Services;
using System.Text.Json;

namespace GlamourLog.Windows.GuideWindow;

public partial class GuideWindow {
    private static Page ExportData => new() {
        CategoryTitle = Loc.T("Export", "导出"),
        SubCategoryTitle = Loc.T("Data Export", "数据导出"),
        Blocks =
        [
            new GuideTextBlock(
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .Append(Loc.T("Here you can export your dresser and armoire data into a format importable into websites and other plugins.", "在此你可以将幻化柜与衣柜的数据导出为可导入网站或其他插件的格式。"))
                        .Encode())),
            new DataExportActionBlock(GlamourDataExportFormat.LalaAchievements),
        ],
    };

    private static void CopyDataExportToClipboard(GlamourDataExportFormat format) {
        if (format is not GlamourDataExportFormat.LalaAchievements)
            return;

        OwnershipService.Get().BuildLalaExport(out var outfitsBySetId, out var armoireIds);
        var json = JsonSerializer.Serialize(new { outfits = outfitsBySetId, armoires = armoireIds });
        ImGui.SetClipboardText(json);
    }
}
