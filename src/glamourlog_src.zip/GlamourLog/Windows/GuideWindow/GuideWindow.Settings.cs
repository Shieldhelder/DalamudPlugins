using FFXIVClientStructs.FFXIV.Component.GUI;
using GlamourLog.Services;

namespace GlamourLog.Windows.GuideWindow;

public unsafe partial class GuideWindow {
    private static Page SettingsLogWindow => new() {
        CategoryTitle = Loc.T("Settings", "设置"),
        SubCategoryTitle = Loc.T("Glamour Log Window", "幻化记录窗口"),
        Blocks = [
            new CheckboxSettingBlock(
                Loc.T("Chinese UI", "简体中文界面"),
                Loc.T("Switch all plugin text to Simplified Chinese. Changing this reopens the open windows.", "将插件界面文字切换为简体中文。切换后会自动重新打开已开启的窗口。"),
                () => C.Language == UiLanguage.SimplifiedChinese,
                v => C.Language = v ? UiLanguage.SimplifiedChinese : UiLanguage.English,
                () => WindowsService.Get().RefreshLanguage()),
            new CheckboxSettingBlock(
                Loc.T("Dark text theme", "深色文字主题"),
                Loc.T("Uses darker text and foreground colors across the plugin UI. Intended for light backgrounds. Changing this reopens the open windows.", "将插件界面的文字与前景元素改用深色，适合浅色背景使用。切换后会自动重新打开已开启的窗口。"),
                () => C.Theme == UiTheme.DarkText,
                v => C.Theme = v ? UiTheme.DarkText : UiTheme.Default,
                () => WindowsService.Get().RefreshTheme()),
            new CheckboxSettingBlock(
                Loc.T("Disable force window closing", "禁止强制关闭窗口"),
                Loc.T("Prevents the game from closing the addon when you go through an area transition or cutscene. Will still hide the addon. Also disables the ability to close via ESC. Must be clicked manually.", "防止在切图或过场动画时游戏强制关闭本窗口（仍会隐藏窗口）。同时禁用按 ESC 关闭。需要手动点击关闭。"),
                () => C.DisableClose,
                v => C.DisableClose = v,
                () => {
                    AtkUnitBase* addon = WindowsService.Get().LogWindow;
                    if (addon is not null)
                        addon->ShouldFireCallbackAndHideOrClose = C.DisableClose;
                }),
            new CheckboxSettingBlock(
                Loc.T("Persist search", "保留搜索内容"),
                Loc.T("Keeps the search text when the Glamour Log window is closed and reopened.", "关闭并重新打开幻化记录窗口时，保留搜索框中的文字。"),
                () => C.PersistSearch,
                v => C.PersistSearch = v),
        ],
    };
}
