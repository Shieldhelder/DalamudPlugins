using Dalamud.Game.Text.SeStringHandling;

namespace GlamourLog.Windows.GuideWindow;

public partial class GuideWindow {
    private static Page Integrations => new() {
        CategoryTitle = Loc.T("Guide", "指南"),
        SubCategoryTitle = Loc.T("Plugin Integrations", "插件联动"),
        Blocks =
        [
            new GuideTextBlock(
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .Append(Loc.T("GlamourLog does not require other plugins to work, but it can be enhanced with other plugins.", "Glamour Log 本身不需要其他插件即可运行，但可以借助其他插件增强功能。"))
                        .Encode())),
            new GuideTextBlock(
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .EmphasisStyled(Loc.T("Allagan Tools", "Allagan Tools"))
                        .Append(Loc.T(" is used in the ", " 用于「套装详情」中的「"))
                        .HighlightStyled(Loc.T("currencies required", "通过兑换获得"))
                        .Append(Loc.T(" section of set details to get the amount of currency you have obtained in any inventory on your character. If not installed, this count will default to your standard inventory only.", "」部分，统计你的角色任意背包中已拥有的货币数量。若未安装，则只统计普通背包中的货币。"))
                        .Encode())),
            new GuideTextBlock(
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .EmphasisStyled(Loc.T("vnavmesh", "vnavmesh"))
                        .Append(Loc.T(" is used in the context menu of ", " 用于「"))
                        .HighlightStyled(Loc.T("Sources and Costs.", "可获取或兑换"))
                        .Append(Loc.T(" If installed, this context menu entry will navigate you to the relevant source of the item.", "」部分的右键菜单。若已安装 vnavmesh，该菜单项会引导你前往物品的对应获取来源。"))
                        .Encode())),
            new GuideTextBlock(
                new Lumina.Text.ReadOnly.ReadOnlySeString(
                    new SeStringBuilder()
                        .EmphasisStyled(Loc.T("AutoDuty", "AutoDuty"))
                        .Append(Loc.T(" is used in the context menu of duty ", "用于副本「"))
                        .HighlightStyled(Loc.T("Sources.", "来源"))
                        .Append(Loc.T(" If installed, this context menu entry will start an AutoDuty loop where your character will run the relevant dungeon until all missing outfit pieces are acquired.", "」的右键菜单。若已安装，可通过该菜单项启动 AutoDuty 循环，自动刷取相应副本，直到集齐缺失的套装部件。"))
                        .Encode())),
        ],
    };
}
