using Dalamud.Game.Text.SeStringHandling;

namespace GlamourLog.Windows.GuideWindow;

public partial class GuideWindow {
    private static Page GuideCounters => new() {
        CategoryTitle = Loc.T("Guide", "指南"),
        SubCategoryTitle = Loc.T("Counters", "计数"),
        Body = new Lumina.Text.ReadOnly.ReadOnlySeString(
                new SeStringBuilder().Append(Loc.T("The bottom-right of the glamour log displays two numbers. The top number is the amount of sets you have completed out of the total number of sets available in the game.\n", "幻化记录右下角显示两个数字。上方的数字是你在游戏中全部套装里已完成的数量。\n"))
                .Append(Loc.T("The bottom number is the amount of glamour dresser slots you have\nsaved by having these pieces stored as outfits instead of being loose inside the dresser.\n\n", "下方的数字是：由于部件以套装形式存放在投影台中（而非散放）而节省下的投影台格子数。\n\n"))
                .FootnoteStyled(Loc.T("Completed counter combines sets in the dresser and the armoire.\n", "完成度计数包含存放在投影台与收藏柜中的套装。\n"))
                .FootnoteStyled(Loc.T("\"Misc Armoire\" are not included in either counters.", "\"其他独立幻化\"不计入上述两种计数。")).Encode()),
    };
}
