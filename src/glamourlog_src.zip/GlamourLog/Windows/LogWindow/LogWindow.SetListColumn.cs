using System.ComponentModel;
using FFXIVClientStructs.FFXIV.Client.UI.Misc;
using GlamourLog.Nodes;
using GlamourLog.Services;
using GlamourLog.Windows.LogWindow;

namespace GlamourLog;

internal unsafe partial class LogWindow {
    private void RefreshRows(OwnershipQuery q, bool refreshCategoryCounts) {
        if (SetList is null || _statsSetsLine is null || _statsSpaceLine is null)
            return;

        if (ItemFinderModule.Instance() is null) {
            _statsSetsLine.String = "\u2014 / \u2014";
            _statsSpaceLine.String = string.Empty;
            return;
        }

        if (refreshCategoryCounts)
            RefreshCategoryCounts(q);

        RepopulateSetListFromFilteredRows(q);
    }

    private void RefreshCategoryCounts(OwnershipQuery q) {
        if (_statsSetsLine is null || _statsSpaceLine is null)
            return;

        if (ItemFinderModule.Instance() is null) {
            _statsSetsLine.String = "\u2014 / \u2014";
            _statsSpaceLine.String = string.Empty;
            return;
        }

        var mirageCatalogSets = CatalogService.Get().GlamourSets.Where(s => !s.NonSetCabinetPiece).ToList();
        var counts = q.CountCompletions(mirageCatalogSets);
        _statsSetsLine.String = $"{counts.OwnedObtainable} / {counts.TotalObtainable}";
        // dresser space saved still includes every complete outfit (obtainable or not)
        _statsSpaceLine.String = $"{mirageCatalogSets.Where(s => q.For(s).IsComplete).Sum(x => x.Items.Count - 1)}";
        _categoryColumn?.UpdateButtonStates(_selectedCategoryId, CategoryRows, q, refreshCounts: true);
    }

    private void RebuildSetListOrderOnly() {
        if (SetList is null)
            return;
        if (ItemFinderModule.Instance() is null)
            return;

        RepopulateSetListFromFilteredRows(OwnershipService.Get().Query());
    }

    private void RepopulateSetListFromFilteredRows(OwnershipQuery q) {
        if (SetList is null)
            return;

        var categoryRows = CategoryRows(_selectedCategoryId);
        SyncCurrencyFilterOptions();

        var searchRaw = _categoryColumn?.Search.Input.String.ToString() ?? string.Empty;
        var searchTrimmed = string.IsNullOrWhiteSpace(searchRaw) ? string.Empty : searchRaw.Trim();
        var rows = SetListFilterSort.Apply(searchTrimmed, categoryRows, q, _currencyFilterItemId);

        _setListOptions.Clear();
        foreach (var set in rows) {
            try {
                _setListOptions.Add(BuildSetListRowData(set, q));
            }
            catch (Exception ex) {
                Svc.Log.Error(ex, $"[{nameof(LogWindow)}] Build virtual set row failed");
            }
        }

        SetList.OptionsList = [.. _setListOptions];
        if (_pendingClearSetSelection) {
            _pendingClearSetSelection = false;
            SetList.ClearSelection();
        }
        else {
            SyncSetListSelectionHighlight(); // OptionsList replaces row refs, gotta rebind SelectedItems so the highlight matches _selectedSet
        }

        if (_pendingResetSetScroll) {
            _pendingResetSetScroll = false;
            SetList.ResetScroll();
        }

        if (_pendingSelectSet is { } pendingSet) {
            _pendingSelectSet = null;
            ScrollSetListToSet(pendingSet);
        }
    }

    private void SyncCurrencyFilterOptions() {
        if (_setListColumn is null)
            return;

        var catalog = CatalogService.Get();
        var currencies = catalog.GetCurrencyFilterItemIds(_selectedCategoryId == AllCategoryId ? null : _selectedCategoryId);
        if (_currencyFilterItemId != SetListCurrencyFilterNode.NoneCurrencyId && !currencies.Contains(_currencyFilterItemId))
            _currencyFilterItemId = SetListCurrencyFilterNode.NoneCurrencyId;

        var dropDown = _setListColumn.CurrencyFilter.DropDown;
        var expectedOptionCount = currencies.Count + 1;
        if (_lastCurrencyFilterOptions is not null
            && _lastCurrencyFilterOptions.Count == currencies.Count
            && _lastCurrencyFilterOptions.SequenceEqual(currencies)
            && dropDown.SelectedOption == _currencyFilterItemId
            && dropDown.Options.Count == expectedOptionCount) // must match count too, because the dropdown rebuilds its options on open and may have only "All" if the category changed
            return;

        _lastCurrencyFilterOptions = currencies;
        _setListColumn.CurrencyFilter.SyncOptions(currencies, _currencyFilterItemId);
    }

    private void OnCurrencyFilterSelected(uint currencyItemId) {
        if (_currencyFilterItemId == currencyItemId)
            return;
        _currencyFilterItemId = currencyItemId;
        _pendingResetSetScroll = true;
        QueueSetListRefresh();
    }

    private void SyncSetListSelectionHighlight() {
        if (SetList is null)
            return;

        SetList.SelectedItems.Clear();
        if (_selectedSet is not { } selected)
            return;

        if (SetList.OptionsList.Find(r => ReferenceEquals(r.Set, selected)) is not null and var row)
            SetList.SelectedItems.Add(row);
    }

    private void ScrollSetListToSet(GlamourSet set) {
        if (SetList is null)
            return;

        var index = SetList.OptionsList.FindIndex(r => r.Set.ItemId == set.ItemId);
        if (index < 0)
            return;

        var stride = (int)(GlamourSetListItemNode.ItemHeight + SetList.ItemSpacing);
        if (stride < 1)
            return;

        var nodeCount = Math.Max(1, (int)(SetList.Height / stride));
        var maxScroll = Math.Max(0, SetList.OptionsList.Count - nodeCount);
        var scroll = Math.Clamp(index, 0, maxScroll);

        SetList.ScrollBarNode.OnValueChanged?.Invoke(scroll * stride);
    }

    private void ClearSetSearchIfActive() {
        if (_categoryColumn is null)
            return;
        var current = _categoryColumn.Search.Input.String.ToString();
        if (string.IsNullOrWhiteSpace(current))
            return;
        _categoryColumn.Search.Input.String = string.Empty;
        _persistedSearch = string.Empty;
    }

    private SetListRowData BuildSetListRowData(GlamourSet set, OwnershipQuery q, bool appendNotInListSuffix = false) {
        var status = q.For(set);
        var subtitle = SetSublineText(status);
        if (appendNotInListSuffix) {
            var searchRaw = _categoryColumn?.Search.Input.String.ToString() ?? string.Empty;
            var searchTrimmed = string.IsNullOrWhiteSpace(searchRaw) ? string.Empty : searchRaw.Trim();
            if (C.HideSharedModels && !SetListFilterSort.IsVisibleInSetList(set, searchTrimmed, CategoryRows(_selectedCategoryId), q, _currencyFilterItemId))
                subtitle += " · " + Loc.T("Not in list", "不在列表中");
        }

        return new SetListRowData {
            Set = set,
            Title = set.Name,
            Subtitle = subtitle,
            IsOwned = status.IsComplete,
            IsUnobtainable = set.IsUnobtainable,
            IsMogstation = set.IsMogstation,
            ShowStorage = status.Storage is SetStorageState.Dresser or SetStorageState.Armoire,
            ShowArmoireWarning = status.ArmoireMisplaced,
            StorageIconPart = status.Storage == SetStorageState.Armoire ? GlamourIconNode.IconPart.Armoire : GlamourIconNode.IconPart.Dresser,
        };
    }

    // build a row for a lookalike item that may not have its own set
    private SetListRowData BuildSharedModelItemRow(uint itemId, OwnershipQuery q) {
        var catalog = CatalogService.Get();
        var set = catalog.FindCatalogSetForItem(itemId)
            ?? new GlamourSet { // fake a one-piece set so the normal row renderer gets reused
                ItemId = itemId,
                Name = Item.GetRow(itemId).Name.ToString(),
                CategoryName = null,
                IsUnobtainable = false,
                BaseIsUnobtainable = false,
                Items = [itemId],
                ItemLevel = Item.GetRow(itemId).LevelItem.RowId,
                PatchNo = 0m,
                NonSetCabinetPiece = true,
                IsIncompatible = false,
                IsMogstation = SetListFilterSort.IsMogstationItem(itemId),
                ModelSignature = SetModelSignature.ForMiscSingle(itemId),
                SharedModelGroupSize = 1,
                HasPartialSharedModels = false,
            };

        var piece = q.For(set).Piece(itemId);
        var location = piece?.Location ?? q.Locate(itemId);
        var ownedInStorage = location is PieceLocation.Armoire or PieceLocation.LooseDresser or PieceLocation.OutfitSlot;
        var ownedAnywhere = location is not PieceLocation.None;
        var subtitle = ownedInStorage ? Loc.T("Obt. 1/1", "已收集 1/1") : ownedAnywhere ? Loc.T("In inventory", "在背包中") : Loc.T("Obt. 0/1", "已收集 0/1");

        var storageState = piece?.BadgeLocation ?? location switch {
            PieceLocation.Armoire => ItemStorageState.Armoire,
            PieceLocation.LooseDresser => ItemStorageState.DresserLoose,
            PieceLocation.OutfitSlot => ItemStorageState.DresserSet,
            _ => ItemStorageState.None,
        };

        var iconPart = storageState switch {
            ItemStorageState.Armoire => GlamourIconNode.IconPart.Armoire,
            ItemStorageState.DresserLoose => GlamourIconNode.IconPart.DresserFaded,
            ItemStorageState.DresserSet => GlamourIconNode.IconPart.Dresser,
            _ => GlamourIconNode.IconPart.Dresser,
        };

        return new SetListRowData {
            Set = set,
            Title = Item.GetRow(itemId).Name.ToString(),
            Subtitle = subtitle,
            IsOwned = ownedInStorage,
            IsUnobtainable = set.IsUnobtainable,
            IsMogstation = set.IsMogstation,
            ShowStorage = storageState is ItemStorageState.DresserSet or ItemStorageState.DresserLoose or ItemStorageState.Armoire,
            ShowArmoireWarning = piece?.ShowArmoireWarning ?? false,
            StorageIconPart = iconPart,
            IconItemId = itemId,
        };
    }

    private void OnSetListSortModeSelected(GlamourSetSortMode mode) {
        if (C.SetListSortMode == mode)
            return;
        C.SetListSortMode = mode;
        C.SetListSortDirection = mode.DefaultDirection();
        C.Save();
        _setListColumn?.SyncSortDirectionChrome();
        QueueSetListRefresh();
    }

    private void OnSetListSortDirectionToggle() {
        C.SetListSortDirection = C.SetListSortDirection == ListSortDirection.Ascending ? ListSortDirection.Descending : ListSortDirection.Ascending;
        C.Save();
        _setListColumn?.SyncSortDirectionChrome();
        if (!IsOpen || !CanPaintLists())
            return;
        _pendingRebuildSetListOrderOnly = true;
    }

    private static string SetSublineText(SetStatus status) {
        var set = status.Set;
        var n = set.Items.Count;
        var c = status.OwnedCount;
        string core;
        if (set.NonSetCabinetPiece) {
            core = status.IsComplete ? Loc.F("Obt. 1/1", "已收集 1/1") : Loc.F("Obt. {0}/1", "已收集 {0}/1", c);
        }
        else if (status.IsComplete)
            core = Loc.F("Obt. {0}/{0}", "已收集 {0}/{0}", n);
        else if (n == 0)
            core = Loc.T("Obt. 0/0", "已收集 0/0");
        else if (c == n)
            core = Loc.T("Completable", "可完成"); // every piece owned, but at least one still needs storing
        else
            core = Loc.F("Obt. {0}/{1}", "已收集 {0}/{1}", c, n);

        var sortHint = C.SetListSortMode switch {
            GlamourSetSortMode.Patch => set.PatchNo == 0m ? Loc.T("Patch —", "版本 —") : Loc.F("Patch {0}", "版本 {0}", set.PatchNo),
            GlamourSetSortMode.ItemLevel => set.ItemLevel == 0 ? Loc.T("iLvl —", "装等 —") : Loc.F("iLvl {0}", "装等 {0}", set.ItemLevel),
            _ => null,
        };
        return sortHint is null ? core : $"{core} · {sortHint}";
    }
}
