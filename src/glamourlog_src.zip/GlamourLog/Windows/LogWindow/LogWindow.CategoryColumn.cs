using GlamourLog.Services;

namespace GlamourLog;

internal partial class LogWindow {
    private List<string> BuildOrderedCategoryPaneList() {
        var r = new List<string> { AllCategoryId, CatalogService.Get().UncategorizedTab.Name };
        foreach (var (category, _) in CatalogService.Get().OutfitCategories.Select((c, ix) => (c, ix)).OrderBy(x => x.c.UiPriority).ThenBy(x => x.ix))
            r.Add(category.Name);
        r.Add(CatalogService.Get().MiscArmoireTab.Name);
        return r;
    }

    private void RebuildCategoryButtonsFromPaneOrder() {
        _categoryColumn?.RebuildFromPaneOrder(_categoryPaneOrder, _selectedCategoryId);
    }

    private IReadOnlyList<GlamourSet> CategoryRows(string categoryId)
        => categoryId == AllCategoryId ? CatalogService.Get().GlamourSets : CatalogService.Get().GlamourSetsByCategory.TryGetValue(categoryId, out var list) ? list : [];

    private void SyncCategoryPaneToDataVersion() {
        if (_categoryColumn is null)
            return;

        var catalog = CatalogService.Get();
        var dataVersion = catalog.DataVersion;
        if (_lastDataVersion == dataVersion)
            return;

        _lastDataVersion = dataVersion;

        var newOrder = BuildOrderedCategoryPaneList();
        if (CategoryPaneOrderMatches(newOrder))
            return;

        _categoryPaneOrder.Clear();
        _categoryPaneOrder.AddRange(newOrder);
        _pendingCategoryPaneRebuild = true;
        if (!_categoryPaneOrder.Contains(_selectedCategoryId))
            _selectedCategoryId = catalog.UncategorizedTab.Name;
        SetList?.ResetScroll();
    }

    private bool CategoryPaneOrderMatches(List<string> newOrder) {
        if (_categoryPaneOrder.Count != newOrder.Count)
            return false;
        for (var i = 0; i < newOrder.Count; i++) {
            if (_categoryPaneOrder[i] != newOrder[i])
                return false;
        }
        return true;
    }
}
