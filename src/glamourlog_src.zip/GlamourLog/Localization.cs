namespace GlamourLog;

public enum UiLanguage {
    English = 0,
    SimplifiedChinese = 1,
}

/// <summary>
/// Tiny localization helper. Translations are reviewed/refined in the "Localization" section below.
/// "en" is the source string used everywhere else in the codebase; "zh" is the Simplified Chinese text.
/// </summary>
public static class Loc {
    public static UiLanguage Language => Configuration.C.Language;
    public static bool IsChinese => Language == UiLanguage.SimplifiedChinese;

    /// <summary>Pick the localized text for the current UI language.</summary>
    public static string T(string en, string zh)
        => IsChinese ? zh : en;

    /// <summary>Pick + format. Both languages must keep the same {0}/{1}... placeholders.</summary>
    public static string F(string en, string zh, params object[] args)
        => string.Format(IsChinese ? zh : en, args);
}
