namespace GlamourLog;

public enum UiTheme {
    Default = 0,

    /// <summary>Uses darker text/foreground colors across the UI (intended for light backgrounds).</summary>
    DarkText = 1,
}
