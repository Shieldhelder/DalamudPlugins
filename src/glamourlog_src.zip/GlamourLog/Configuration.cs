using System.ComponentModel;
using Dalamud.Configuration;
using Newtonsoft.Json;

namespace GlamourLog;

[Serializable]
public class Configuration : IPluginConfiguration, IPluginService {
    [JsonIgnore] public int InitOrder => -100;
    [JsonIgnore] public static Configuration C => Configuration.Get();

    public int Version { get; set; } = 0;

    public bool HideCompleted { get; set; }
    public bool ShowOnlyCompleted { get; set; }
    public bool HideIncompatible { get; set; }
    public bool HideUnobtainable { get; set; }
    public bool HideMogstation { get; set; }
    public bool HideNonPartials { get; set; }
    public bool HideUnaffordable { get; set; }
    public bool HideUnready { get; set; }
    public bool HideNoMarketboard { get; set; }
    public bool ShowOnlyMisplaced { get; set; }
    public bool HideSharedModels { get; set; }

    public GlamourSetSortMode SetListSortMode { get; set; } = GlamourSetSortMode.Alphabetical;
    public ListSortDirection SetListSortDirection { get; set; } = ListSortDirection.Ascending;

    public bool DisableClose { get; set; } = true;
    public bool PersistSearch { get; set; }

    public UiLanguage Language { get; set; } = UiLanguage.SimplifiedChinese;
    public UiTheme Theme { get; set; } = UiTheme.Default;

    public bool HideCabinetOwnedItems { get; set; }
    public bool HideCabinetGearsetItems { get; set; }

    public bool HideCrystallizeOwnedItems { get; set; }
    public bool HideCrystallizeArmoireEligibleItems { get; set; }
    public bool HideCrystallizeNonOutfitItems { get; set; }

    public void Save() => Svc.Interface.SavePluginConfig(this);
}
