# -*- coding: utf-8 -*-
"""Regenerate docs/localization_table.csv from all Loc.T/Loc.F calls + runtime texts.

Usage: python docs/gen_localization_csv.py
Keeps the CSV as the single source of truth for translators.
"""
import io
import os
import re
from collections import OrderedDict

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "GlamourLog")
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "localization_table.csv")

# manual remarks keyed by (en, zh)
REMARKS = {
    (" This item can go in your armoire!", "这件物品可以放入收藏柜！"): "运行时聊天提示(非 Loc)",
    (" The final piece of ", "这是套装 "): "运行时聊天提示前缀(非 Loc)",
    ("!", " 的最后一件！"): "运行时聊天提示后缀(非 Loc)",
    (" {0}/{1} of the set ", "套装 {0}/{1} 收集进度"): "运行时聊天提示前缀(非 Loc)",
    ("!", "！"): "运行时聊天提示后缀(非 Loc)",
}


def parse_string(src, i):
    assert src[i] == '"'
    j = i + 1
    while j < len(src):
        c = src[j]
        if c == "\\":
            j += 2
            continue
        if c == '"':
            return src[i:j + 1], j + 1
        j += 1
    return None, i


def literal_value(tok):
    body = tok[1:-1]
    out = []
    k = 0
    while k < len(body):
        c = body[k]
        if c == "\\":
            n = body[k + 1] if k + 1 < len(body) else ""
            if n == "n":
                out.append("\\n")
            elif n == '"':
                out.append('"')
            elif n == "\\":
                out.append("\\")
            elif n == "t":
                out.append("\\t")
            else:
                out.append(c)
            k += 2
        else:
            out.append(c)
            k += 1
    return "".join(out)


rows = OrderedDict()  # (en, zh) -> set(files)


def register(en, zh, rel):
    rows.setdefault((en, zh), set()).add(rel)


pat = re.compile(r"\bLoc\.(T|F)\s*\(")

for dirpath, _, files in os.walk(ROOT):
    for fn in files:
        if not fn.endswith(".cs"):
            continue
        p = os.path.join(dirpath, fn)
        rel = os.path.relpath(p, ROOT).replace("\\", "/")
        src = io.open(p, encoding="utf-8").read()
        for m in pat.finditer(src):
            i = m.end()
            while i < len(src) and src[i] in " \t\n\r":
                i += 1
            if i >= len(src) or src[i] != '"':
                continue
            tok1, i = parse_string(src, i)
            if tok1 is None:
                continue
            while i < len(src) and src[i] in " \t\n\r":
                i += 1
            if i >= len(src) or src[i] != ',':
                continue
            i += 1
            while i < len(src) and src[i] in " \t\n\r":
                i += 1
            if i >= len(src) or src[i] != '"':
                continue
            tok2, i = parse_string(src, i)
            if tok2 is None:
                continue
            register(literal_value(tok1), literal_value(tok2), rel)

# runtime texts appended to chat loot notices (language branches, not Loc calls)
runtime_chat = [
    (" This item can go in your armoire!", "这件物品可以放入收藏柜！"),
    (" The final piece of ", "这是套装 "),
    ("!", " 的最后一件！"),
    (" {0}/{1} of the set ", "套装 {0}/{1} 收集进度"),
    ("!", "！"),
]
for en, zh in runtime_chat:
    register(en, zh, "Tweaks/ChatAlerts.cs")

items = []
for (en, zh), files in rows.items():
    remark = REMARKS.get((en, zh), "")
    if "Tweaks/ChatAlerts.cs" in files and not remark:
        remark = "运行时聊天提示"
    items.append((en, zh, "; ".join(sorted(files)), remark))

items.sort(key=lambda r: (r[0].lower(), r[1]))


def csv_field(v):
    return '"' + v.replace('"', '""') + '"'


with io.open(OUT, "w", encoding="utf-8-sig", newline="") as fp:
    fp.write(",".join(csv_field(x) for x in ["English (source)", "简体中文", "使用位置(文件)", "备注"]) + "\r\n")
    for en, zh, loc, note in items:
        fp.write(",".join(csv_field(x) for x in [en, zh, loc, note]) + "\r\n")

print("wrote", OUT, "rows:", len(items))
